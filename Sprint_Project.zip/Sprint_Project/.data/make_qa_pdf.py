from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white, Color
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, PageBreak, Flowable, KeepTogether)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER

OUT = r'D:\PROJECTS\EYE_CARE\Sprint_Project\Team_Sprint_QA_User_Flow_Guide.pdf'
W, H = A4
INK = HexColor('#14183a'); MUTED = HexColor('#5b6389'); LINE = HexColor('#d9dcf0'); BG = HexColor('#f6f7fd')
VIOLET = HexColor('#6a47f5'); CYAN = HexColor('#0ea5c6'); PINK = HexColor('#e0559a'); GREEN = HexColor('#10a874'); AMBER = HexColor('#d98e04'); RED = HexColor('#e04848'); BLUE = HexColor('#2f7de1'); SLATE = HexColor('#8a91b3')
def mix(c, a=0.12): return Color(1 - (1 - c.red) * a, 1 - (1 - c.green) * a, 1 - (1 - c.blue) * a)

def S(name, size=9.2, color=INK, bold=False, lead=None, align=TA_LEFT, **kw):
    return ParagraphStyle(name, fontName='Helvetica-Bold' if bold else 'Helvetica', fontSize=size, leading=lead or size * 1.38, textColor=color, alignment=align, **kw)
body = S('body'); small = S('small', 8.2, MUTED); cell = S('cell', 8.6, lead=11.4); cellb = S('cellb', 8.6, bold=True, lead=11.4); head = S('head', 8.4, white, True)
h1 = S('h1', 20, INK, True, 24, spaceAfter=2); h2 = S('h2', 12.5, INK, True, 16, spaceBefore=8, spaceAfter=3)

class FlowStrip(Flowable):
    """Horizontal chain of coloured step chips with arrows."""
    def __init__(self, labels, color=VIOLET, width=W - 36 * mm):
        super().__init__(); self.labels = labels; self.color = color; self.width = width; self.height = 34
    def wrap(self, aw, ah): return self.width, self.height
    def draw(self):
        c = self.canv; n = len(self.labels); gap = 14; bw = (self.width - gap * (n - 1)) / n
        for i, t in enumerate(self.labels):
            x = i * (bw + gap)
            col = [VIOLET, CYAN, PINK, GREEN, AMBER, BLUE][i % 6] if self.color is None else self.color
            c.setFillColor(mix(col, 0.13)); c.setStrokeColor(col); c.setLineWidth(1); c.roundRect(x, 2, bw, 30, 8, stroke=1, fill=1)
            c.setFillColor(col); c.circle(x + 11, 17, 6, stroke=0, fill=1); c.setFillColor(white); c.setFont('Helvetica-Bold', 7.5); c.drawCentredString(x + 11, 14.5, str(i + 1))
            c.setFillColor(INK); c.setFont('Helvetica-Bold', 7.6)
            words = t.split(); lines = []; cur = ''
            for w in words:
                if c.stringWidth((cur + ' ' + w).strip(), 'Helvetica-Bold', 7.6) < bw - 26: cur = (cur + ' ' + w).strip()
                else: lines.append(cur); cur = w
            lines.append(cur)
            y0 = 17 + (len(lines) - 1) * 4.2 - 2.6
            for k, ln in enumerate(lines[:3]): c.drawString(x + 21, y0 - k * 8.4, ln)
            if i < n - 1:
                c.setStrokeColor(SLATE); c.setFillColor(SLATE); c.setLineWidth(1.4); c.line(x + bw + 2, 17, x + bw + gap - 3, 17)
                p = c.beginPath(); p.moveTo(x + bw + gap - 1, 17); p.lineTo(x + bw + gap - 6, 20); p.lineTo(x + bw + gap - 6, 14); p.close(); c.drawPath(p, stroke=0, fill=1)

class Band(Flowable):
    """Section title band."""
    def __init__(self, num, title, sub, color=VIOLET):
        super().__init__(); self.num = num; self.title = title; self.sub = sub; self.color = color; self.width = W - 36 * mm; self.height = 46
    def wrap(self, aw, ah): return self.width, self.height
    def draw(self):
        c = self.canv
        c.setFillColor(INK); c.roundRect(0, 0, self.width, self.height, 10, stroke=0, fill=1)
        c.setFillColor(self.color); c.roundRect(0, 0, 6, self.height, 3, stroke=0, fill=1)
        c.setFillColor(self.color); c.circle(28, self.height / 2, 14, stroke=0, fill=1); c.setFillColor(white); c.setFont('Helvetica-Bold', 12); c.drawCentredString(28, self.height / 2 - 4.2, str(self.num))
        c.setFont('Helvetica-Bold', 14.5); c.drawString(52, self.height - 20, self.title)
        c.setFont('Helvetica', 8.8); c.setFillColor(HexColor('#b6bcf0')); c.drawString(52, 11, self.sub)

def P(t, st=cell): return Paragraph(t, st)
def steps(rows, color=VIOLET, widths=(9 * mm, 78 * mm, 83 * mm)):
    data = [[P('#', head), P('What the tester does', head), P('What should happen', head)]] + [[P(str(i + 1), cellb), P(a), P(b)] for i, (a, b) in enumerate(rows)]
    t = Table(data, colWidths=list(widths), repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), color), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, mix(color, 0.06)]),
                           ('LINEBELOW', (0, 0), (-1, -1), 0.4, LINE), ('BOX', (0, 0), (-1, -1), 0.6, LINE), ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4), ('LEFTPADDING', (0, 0), (-1, -1), 5), ('RIGHTPADDING', (0, 0), (-1, -1), 5)]))
    return t
def box(title, lines, color=GREEN, widths=(170 * mm,)):
    items = [P(f'<b>{title}</b>', S('bt', 8.8, color, True))] + [P('&bull; ' + l, S('bl', 8.4, lead=11)) for l in lines]
    t = Table([[i] for i in items], colWidths=list(widths))
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), mix(color, 0.08)), ('LINEBEFORE', (0, 0), (0, -1), 3, color), ('BOX', (0, 0), (-1, -1), 0.5, mix(color, 0.4)), ('LEFTPADDING', (0, 0), (-1, -1), 9), ('TOPPADDING', (0, 0), (-1, -1), 1.5), ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5), ('TOPPADDING', (0, 0), (-1, 0), 5), ('BOTTOMPADDING', (0, -1), (-1, -1), 5)]))
    return t
def meta(who, where):
    t = Table([[P('<b>Who can use it</b>', S('m', 8.2, MUTED, True)), P(who, cell), P('<b>Where to find it</b>', S('m', 8.2, MUTED, True)), P(where, cell)]], colWidths=[29 * mm, 52 * mm, 27 * mm, 62 * mm])
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, -1), BG), ('BOX', (0, 0), (-1, -1), 0.5, LINE), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
    return t
def sp(n=6): return Spacer(1, n)

story = []
def section(num, title, sub, color, who, where, flow, rows, ok=None, neg=None, example=None):
    global story
    blk = [Band(num, title, sub, color), sp(5), meta(who, where), sp(6), FlowStrip(flow, color), sp(7), steps(rows, color)]
    story.append(KeepTogether(blk[:5]))
    story.extend(blk[5:])
    if example: story += [sp(6), box('Sample data to use', example, BLUE)]
    if neg: story += [sp(6), box('Also test (should be rejected or behave like this)', neg, RED)]
    if ok: story += [sp(6), box('Pass criteria', ok, GREEN)]
    story.append(PageBreak())

# ------------------------------------------------------------------ cover + setup
class Cover(Flowable):
    def __init__(self): super().__init__(); self.width = W - 36 * mm; self.height = 230
    def wrap(self, aw, ah): return self.width, self.height
    def draw(self):
        c = self.canv; c.setFillColor(INK); c.roundRect(0, 0, self.width, self.height, 16, stroke=0, fill=1)
        for k, col in enumerate([VIOLET, CYAN, PINK]):
            c.setFillColor(Color(col.red, col.green, col.blue, alpha=0.10)); c.circle(40 + k * 150, 40 + k * 20, 90, stroke=0, fill=1)
        c.setFillColor(white); c.roundRect(24, self.height - 90, 120, 56, 12, stroke=0, fill=1)
        try: c.drawImage(r'D:\PROJECTS\EYE_CARE\Sprint_Project\public\brand\logo-full.png', 28, self.height - 88, width=112, height=52, preserveAspectRatio=True, mask='auto')
        except Exception: pass
        c.setFont('Helvetica-Bold', 27); c.drawString(24, 98, 'QA User Flow Guide')
        c.setFont('Helvetica', 12); c.setFillColor(HexColor('#b6bcf0')); c.drawString(24, 76, 'How every feature is used, step by step, and what the tester should see.')
        c.setFont('Helvetica', 9.5); c.drawString(24, 40, 'Team Sprint  -  work and sprint management   |   Open the app at http://localhost:7000')
story.append(Cover()); story.append(sp(10))
story.append(P('How to use this guide', h2))
story.append(P('Each section covers one area of the application. Read the small flow strip at the top, then follow the numbered table: the left column is what you <b>do</b>, the right column is what you should <b>see</b>. Red boxes list negative tests (things that must be refused). Green boxes are the pass criteria. Use the checklist at the end to record results.', body))
story.append(sp(6))
story.append(P('Test accounts', h2))
acc = [('Role', 'Email', 'Password', 'What this person can do'),
       ('Super Admin', 'superadmin@orbit.dev', 'Orbit@Super123!', 'Everything across all organizations (Platform console)'),
       ('Org Admin', 'admin@acme.dev', 'Orbit@Admin123!', 'Manage Acme members, roles, all projects, audit log'),
       ('Scrum Master', 'priya.lead@acme.dev', 'Orbit@Demo123!', 'Project admin of ACME: sprints, settings, automation'),
       ('Product Owner', 'marcus.po@acme.dev', 'Orbit@Demo123!', 'Project admin of ACME: backlog and goals'),
       ('Developer', 'sara.dev@acme.dev', 'Orbit@Demo123!', 'Create, edit, move issues; work logs'),
       ('QA Engineer', 'lena.qa@acme.dev', 'Orbit@Demo123!', 'Developer rights in ACME / MOB'),
       ('Reporter', 'tom.reporter@acme.dev', 'Orbit@Demo123!', 'Create issues; edit and move only own'),
       ('Viewer', 'vera.viewer@acme.dev', 'Orbit@Demo123!', 'Read-only everywhere'),
       ('Guest', 'guest@client.com', 'Orbit@Demo123!', 'Sees only the Customer Support project')]
data = [[P(x, head) for x in acc[0]]] + [[P(a, cellb), P(b), P(c_), P(d)] for a, b, c_, d in acc[1:]]
t = Table(data, colWidths=[27 * mm, 44 * mm, 33 * mm, 66 * mm], repeatRows=1)
t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), VIOLET), ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, mix(VIOLET, 0.06)]), ('BOX', (0, 0), (-1, -1), 0.6, LINE), ('LINEBELOW', (0, 0), (-1, -1), 0.4, LINE), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 3.5), ('BOTTOMPADDING', (0, 0), (-1, -1), 3.5)]))
story.append(t)
story.append(sp(4)); story.append(P('Tip: on the login page the "Demo accounts" buttons sign you in with one click.', small))
story.append(sp(6))
story.append(P('Sample data you will find', h2))
proj = [('ACME', 'Team Sprint Web App', 'Scrum', '4 closed sprints, Sprint 5 active (day 6 of 14), Sprint 6 future, 80 issues'), ('MOB', 'Mobile Apps', 'Kanban', 'WIP limits set (In Progress 4, In Review 3)'), ('SUP', 'Customer Support', 'Service desk', '25 tickets, some with overdue / at-risk SLA'), ('MKT', 'Marketing Campaigns', 'Business', '20 tasks with due dates'), ('PLAT', 'Platform & Infra', 'Kanban (private)', 'Only Alex (Org Admin), Noah and Kiran can see it'), ('GLX', 'Globex Core', 'Kanban', 'Belongs to a different organization (Globex) - nobody from Acme may see it')]
data = [[P(x, head) for x in ('Key', 'Name', 'Type', 'Notes')]] + [[P(a, cellb), P(b), P(c_), P(d)] for a, b, c_, d in proj]
t = Table(data, colWidths=[16 * mm, 38 * mm, 30 * mm, 86 * mm], repeatRows=1)
t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), CYAN), ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, mix(CYAN, 0.06)]), ('BOX', (0, 0), (-1, -1), 0.6, LINE), ('LINEBELOW', (0, 0), (-1, -1), 0.4, LINE), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 3.5), ('BOTTOMPADDING', (0, 0), (-1, -1), 3.5)]))
story.append(t); story.append(PageBreak())

# ------------------------------------------------------------------ the big picture
story.append(Band(0, 'The whole flow at a glance', 'How a piece of work travels through Team Sprint', INK))
story.append(sp(8))
story.append(FlowStrip(['Sign in', 'Create project', 'Create issues', 'Plan sprint (backlog)', 'Work on board', 'Complete sprint', 'Read reports'], None))
story.append(sp(10))
story.append(P('In plain words', h2))
story.append(P('A <b>project</b> holds <b>issues</b> (stories, bugs, tasks). Issues wait in the <b>backlog</b> until the Scrum Master drags them into a <b>sprint</b> (a 1-4 week time box). When the sprint is <b>started</b>, the team moves issue cards across the <b>board</b> (To Do, In Progress, In Review, QA, Done). People comment, mention each other and log time. Everyone gets <b>notifications</b>. When the time is up, the sprint is <b>completed</b>; unfinished issues go back to the backlog or into the next sprint, and <b>reports</b> (burndown, velocity) show how the team did.', body))
story.append(sp(6))
story.append(P('What each role sees', h2))
roles = [('Super Admin', 'Platform console: all organizations and users. Can impersonate users (with a reason).', RED), ('Org Admin', 'Organization console: members and roles. Can open every project in the org.', AMBER), ('Member', 'Dashboard, projects they may view, filters, goals, workload, inbox.', BLUE), ('Guest', 'Only projects they were added to. No Goals or Workload menu. Cannot create projects.', SLATE)]
data = [[P(a, S('r', 8.8, c_, True)), P(b)] for a, b, c_ in roles]
t = Table(data, colWidths=[28 * mm, 142 * mm]); t.setStyle(TableStyle([('BOX', (0, 0), (-1, -1), 0.6, LINE), ('LINEBELOW', (0, 0), (-1, -1), 0.4, LINE), ('BACKGROUND', (0, 0), (-1, -1), white), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
story.append(t); story.append(sp(8))
story.append(P('Issue statuses (Scrum project)', h2))
story.append(FlowStrip(['To Do', 'In Progress', 'In Review', 'QA', 'Done'], None))
story.append(sp(4)); story.append(P('Kanban: To Do, In Progress, Done.  Business: Backlog, Doing, Review, Done.  Service desk: Waiting for support, In progress, Waiting for customer, Resolved.', small))
story.append(sp(8))
story.append(P('Keyboard shortcuts (not while typing in a field)', h2))
sc = [('Ctrl + K', 'Open the command palette (search anything)'), ('/', 'Open search'), ('C', 'Create an issue'), ('G then D', 'Go to Dashboard'), ('G then P', 'Go to Projects'), ('G then S', 'Go to Filters (search)'), ('G then N', 'Go to Inbox'), ('[', 'Collapse / expand the sidebar'), ('?', 'Show the shortcut list'), ('Esc', 'Close any dialog or menu')]
data = [[P(f'<b>{a}</b>', cell), P(b)] for a, b in sc]
t = Table(data, colWidths=[30 * mm, 140 * mm]); t.setStyle(TableStyle([('ROWBACKGROUNDS', (0, 0), (-1, -1), [white, mix(VIOLET, 0.06)]), ('BOX', (0, 0), (-1, -1), 0.6, LINE), ('TOPPADDING', (0, 0), (-1, -1), 3), ('BOTTOMPADDING', (0, 0), (-1, -1), 3)]))
story.append(t); story.append(PageBreak())

# ------------------------------------------------------------------ sections
section(1, 'Sign in, sign out and create an account', 'Login page, one-click demo accounts, workspace registration', VIOLET,
        'Everyone', 'http://localhost:7000/login and /register',
        ['Open login page', 'Enter email + password', 'Press Sign in', 'Welcome check mark', 'Land on Dashboard'],
        [('Open the site address. You are not signed in.', 'Login page appears with a rotating headline, a mini board animation and the Welcome back card.'),
         ('Type <b>sara.dev@acme.dev</b> and <b>Orbit@Demo123!</b>, press Sign in.', 'Button shows a spinner, then a check mark "Welcome". The card fades out and the Dashboard opens.'),
         ('Sign in as <b>superadmin@orbit.dev</b>.', 'You land on the Platform console, not the Dashboard.'),
         ('Click one of the Demo account buttons (right card).', 'Signs in immediately with that role.'),
         ('Click your avatar (top right) then Sign out.', 'You return to the login page. Pressing the browser Back button does not show private pages.'),
         ('Open /dashboard while signed out.', 'You are sent to the login page; after signing in you arrive on the page you wanted.'),
         ('Click "Create a workspace". Fill name, email, workspace name and a password.', 'Password strength bar fills as you type. After Create workspace you are signed in as the new workspace admin.')],
        neg=['Wrong password: red banner "Incorrect email or password" (same message for an unknown email).', 'Five wrong passwords in a row: "Account locked. Try again in 15 min". Correct password is refused until then.', 'Empty or invalid email: "Enter a valid email".', 'Register with an existing email: "An account with this email already exists".', 'Weak password on register: "Use at least 10 characters", "Add an uppercase letter" or "Add a number".', 'Suspended user signs in: "This account is suspended. Contact your administrator."'],
        ok=['Every role signs in and lands on the correct first page.', 'Signing out really ends the session.'])

section(2, 'Layout, navigation and search', 'Sidebar, top bar, command palette, notifications bell, theme', CYAN,
        'Everyone (menu items depend on role)', 'Left sidebar and top bar on every page',
        ['Use sidebar', 'Press Ctrl + K', 'Type a word', 'Pick a result', 'Page opens'],
        [('Look at the sidebar as Sara.', 'Items: For you, Projects, Filters, Goals, Workload, Inbox. Active item has a highlighted pill that slides when you change page.'),
         ('Sign in as Alex (Org Admin).', 'An extra "Organization" item appears under Administration. Super Admin sees "Platform".'),
         ('Sign in as the Guest.', 'No Goals and no Workload items; the Create button is disabled.'),
         ('Click Collapse (or press [).', 'Sidebar shrinks to the icon rail showing the TS icon; hovering an item shows its name.'),
         ('Press Ctrl + K and type <b>dark</b>.', 'Results list issues such as "Dark theme for charts and data tables" (key + title). Arrow keys move, Enter opens.'),
         ('In the palette type <b>Sara</b>.', 'A People result appears; choosing it opens Filters showing her assigned issues.'),
         ('Click the sun / moon icon.', 'Whole app switches between dark and light and remembers your choice after refresh.'),
         ('Click the bell.', 'Dropdown lists latest notifications with a red unread count; Mark all read clears the count.'),
         ('Press ? on the keyboard.', 'Shortcut list opens.')],
        neg=['Typing in a text box and pressing C or / must NOT trigger shortcuts.', 'Palette with no match shows "No results".'],
        ok=['Menu items match the role.', 'Both themes are readable (no invisible text, including on hover of buttons).'])

section(3, 'Dashboard ("For you")', 'Your personal overview and the focus timer', GREEN,
        'Everyone', 'Sidebar > For you',
        ['Open Dashboard', 'Read the tiles', 'Open an issue', 'Use focus mode', 'Time is logged'],
        [('Sign in as Sara and open For you.', 'Greeting with her first name, 4 count-up tiles (Open issues, Due this week, Overdue, Hours this week).'),
         ('Look at "Assigned to me".', 'List of her open issues sorted by priority, each showing key, title, due date, priority icon and status name (To Do, In Progress...).'),
         ('Click an issue row.', 'Full issue page opens.'),
         ('In Focus mode pick an issue, choose 15m and press Start focus.', 'Ring counts down. Pause / Reset work. The expand icon opens a full-screen timer; Esc closes it.'),
         ('Let a 15-minute session finish (or ask a developer to shorten it).', 'Toast "Focus session complete - 15m logged on ACME-xx"; the issue Work log shows a "Focus session" entry.'),
         ('Check "Active sprints" and "Starred projects".', 'Sprint card with progress ring and days left; starred projects list (Sara starred ACME and MOB).'),
         ('Sign in as the Guest.', 'Tiles show 0 and the page says nothing is assigned; Recent activity shows only Support tickets.')],
        ok=['Numbers match the issues actually assigned to the user.', 'No raw words such as "progress" or "todo" appear; statuses read To Do / In Progress / Done.'])

section(4, 'Projects: list, star and create', 'Browsing projects and the 3-step creation wizard', PINK,
        'Members and admins (Guests cannot create)', 'Sidebar > Projects',
        ['Open Projects', 'Search / star', 'New project', 'Pick template', 'Name + key', 'Add team', 'Create'],
        [('Open Projects as Sara.', 'Cards for ACME, MOB, SUP, MKT (PLAT and GLX are NOT visible). Starred projects come first.'),
         ('Type <b>mob</b> in Search projects.', 'Only Mobile Apps remains. Clear it to see all again.'),
         ('Switch between grid and table view.', 'Same projects shown as cards or as a table with progress bars.'),
         ('Click the star on a card.', 'Star fills instantly; the project also appears under "Starred projects" on the Dashboard.'),
         ('Click New project. Step 1: choose Kanban.', 'Selected template shows a check mark and its workflow chips.'),
         ('Step 2: Name <b>QA Demo</b>. Key fills automatically as <b>QD</b>. Choose a colour.', 'Continue is enabled only when name and key are filled. Key is forced to capital letters.'),
         ('Step 3: tick two colleagues, press Create project.', 'Toast "Project QD created" and the new empty board opens with the Kanban columns.'),
         ('Sign in as Alex (Org Admin) and open Projects.', 'PLAT is now visible (private project) and a lock icon marks it.')],
        neg=['Key already used (e.g. ACME): field error "Key already in use" and the wizard returns to step 2.', 'Key such as "1abc" or "a": "Use 2-10 uppercase letters/numbers, starting with a letter".', 'Guest has no New project button.'],
        ok=['Private projects are visible only to their members and org admins.', 'Created project shows the chosen workflow columns.'])

section(5, 'Create an issue', 'The Create dialog, quick capture and what happens afterwards', VIOLET,
        'Developers, project admins, reporters (not viewers or guests outside SUP)', 'Create button, key C, the + in a board column',
        ['Press C', 'Fill summary + fields', 'Create', 'Toast with Open', 'Issue appears in lists'],
        [('Press <b>C</b> anywhere (or click Create).', 'Create issue dialog opens with Project, Type, Summary, Description, Priority, Assignee, Story points, Due date, Epic, Sprint.'),
         ('Choose project ACME, type Bug, summary <b>Login button not clickable on Safari</b>, priority High, assignee Sara.', 'Create is enabled.'),
         ('Press Create.', 'Dialog closes, toast "ACME-nn created" with an Open link. The new key is the next number in the project.'),
         ('Open Backlog (ACME) and the Issues tab.', 'The new bug is at the bottom of the backlog; Sara receives a notification "assigned you ACME-nn".'),
         ('Open Create again. Type the summary <b>Fix signup typo @sara !high #copy ^2 /bug</b>.', 'A hint line shows what will be parsed. After Create: summary "Fix signup typo", assignee Sara, priority High, label copy, 2 points, type Bug.'),
         ('Tick "Create another", create one issue.', 'Dialog stays open with empty summary for the next one.'),
         ('In a board column press the small + button.', 'Dialog opens with the sprint of the active board preselected.')],
        neg=['Summary of 1-2 characters: "Summary needs at least 3 characters".', 'Vera (Viewer) cannot see the Create button; pressing C does nothing for a Guest.', 'In a project where you are only a Viewer the project is not offered in the Project list.'],
        ok=['Issue keys never repeat.', 'Quick-capture words are removed from the summary and applied to the right fields.'])

section(6, 'Working inside an issue', 'The issue page / side drawer: every editable field', CYAN,
        'Developers and above (Reporters: only issues they created)', 'Click any issue anywhere, or open /issues/ACME-50',
        ['Open issue', 'Change status', 'Edit fields', 'Comment / @mention', 'Log work', 'Check History'],
        [('Open <b>ACME-50</b>.', 'Header shows project > epic > key. Left: summary, description, sub-tasks, tabs. Right: Status, Assignee, Reporter, Priority, Type, Points, Sprint, Epic, Due date, Labels, Time tracking.'),
         ('Click the title, change it, press Enter.', 'Saved immediately; History tab gains an entry.'),
         ('Click the description, add <font face="Courier">- [ ] Test on Safari</font> and Save.', 'A checklist line renders; **bold** and <font face="Courier">`code`</font> render too. ACME-12 style keys become links.'),
         ('Click the Status chip and choose In Review.', 'Chip changes colour at once; watchers get "moved ACME-50 to In Review". Choosing Done shows a "marked done" toast.'),
         ('Use "Assign to me" under Assignee.', 'Assignee becomes you; toast "Assigned to you".'),
         ('Change Priority, Type, Story points, Sprint, Epic and Due date.', 'Each saves on change. A past due date shows a red "Overdue" note while the issue is not done.'),
         ('Add a label by typing it and pressing Enter; remove it with the x.', 'Label chips appear / disappear.'),
         ('Write a comment mentioning <b>@Lena Fischer</b> and press Ctrl + Enter.', 'Comment appears at the top. While typing @ a name suggestion list appears. Lena gets a "mentioned you" notification.'),
         ('Work log tab: enter <b>1h 30m</b>, description "Debugging", Log work.', 'Entry appears; Time tracking shows 1h 30m logged and the total updates. Units: w d h m.'),
         ('Sub-tasks: click "Add sub-task", type a title, Enter.', 'Sub-task row appears with a progress bar for the group.'),
         ('Actions menu (...): Watch, Vote, Flag impediment, Copy link.', 'Watch count and vote count change; flagged issues show a striped warning banner and a flag on the card.'),
         ('Actions menu > Delete (admins only), confirm.', 'Issue disappears from all lists; its sub-tasks are removed too.')],
        neg=['Work log "abc": "Use a format like 2h 30m or 1d".', 'Work log "30d": "That is more than a week of work in one entry".', 'Empty comment: "Write something first".', 'Reporter opens an issue created by someone else: fields are not editable and the status cannot be changed.', 'Viewer sees a "read-only access" note instead of the comment box.', 'Two people edit the same issue and one saves with an old copy: "Someone else updated this issue. Reload to see their changes."'],
        ok=['Every change is visible in the History tab with who / old value / new value.', 'Time logged and estimate bars stay consistent (over estimate turns red).'])

section(7, 'The board (drag and drop)', 'Moving cards, WIP limits, swimlanes and sprint completion', GREEN,
        'Developers move any card; Reporters only their own; Viewers cannot move', 'Project > Active sprint (Scrum) or Board (Kanban)',
        ['Open board', 'Drag card to next column', 'See result', 'Filter / swimlanes', 'Complete sprint'],
        [('Open ACME > Active sprint as Sara.', 'Sprint header with progress ring (57%), goal, days left and points. Columns To Do, In Progress, In Review, QA, Done each show a count.'),
         ('Drag a card from To Do into In Progress and drop.', 'Card lifts with a slight tilt, a gap opens in the target column, card settles. Reload the page: it is still there.'),
         ('Drag a card into Done.', 'Green pulse on the card and toast "ACME-nn done". The sprint ring and points increase.'),
         ('Drag a card up or down inside one column.', 'Order is kept after refresh.'),
         ('Click a card.', 'Issue drawer slides in from the right; closing it keeps the board position.'),
         ('Tick "Only my issues".', 'Only cards assigned to you remain.'),
         ('Tick "Swimlanes by assignee".', 'One board section per person (plus Unassigned), each draggable on its own.'),
         ('Type text in "Filter issues".', 'Cards that do not match disappear.'),
         ('Open MOB > Board and drag a 5th card into In Progress (limit 4).', 'Column border glows red with "WIP exceeded". The move is still allowed - it is a warning.'),
         ('As Priya press Complete sprint.', 'Dialog shows completed and open counts; choose where open issues go (Backlog or Sprint 6) and confirm. Sprint becomes closed and the board shows "No active sprint".')],
        neg=['Tom (Reporter) drags a card he did not create: card shakes and returns, toast "You do not have permission to do that".', 'Vera (Viewer): cards cannot be picked up at all.', 'Cards with a red link icon are blocked by another issue; flagged cards have a striped background; in-progress cards older than 7 days show an age badge such as "9d".'],
        ok=['Every drop is saved and survives a refresh.', 'A rejected drop never leaves the card in the wrong column.'])

section(8, 'Backlog and sprint planning', 'Ordering work, building a sprint, starting it', AMBER,
        'Developers and project admins (sprint actions need sprint rights)', 'ACME > Backlog',
        ['Open backlog', 'Create sprint', 'Drag issues in', 'Start sprint', 'Board shows sprint'],
        [('Open ACME > Backlog.', 'Sections: Sprint 5 (Active), Sprint 6 (future) and Backlog. Each header shows count and points bubbles (To do / In progress / Done).'),
         ('Click "Create sprint".', 'New future sprint appears with a generated name.'),
         ('Drag an issue from Backlog into the future sprint.', 'Issue moves, points total in the sprint header increases; an indicator compares with average velocity (e.g. 5/33 pts).'),
         ('Drag within the Backlog to re-order.', 'New order persists after refresh.'),
         ('Click "Suggest" on the future sprint.', 'Toast says how many issues were added to fill about the average velocity; they appear in the sprint.'),
         ('Use the Epic filter and search box.', 'List narrows to that epic / text.'),
         ('Try Start sprint while Sprint 5 is active.', 'Refused: "Another sprint is already active. Complete it first."'),
         ('Complete Sprint 5, then Start sprint on Sprint 6: choose 2 weeks, add a goal, Start.', 'Sprint turns Active, toast "started", assigned people get a "sprint has started" notification.'),
         ('Delete an empty future sprint (trash icon) and confirm.', 'Its issues (if any) go back to the backlog.')],
        neg=['Start an empty sprint: "Add at least one issue to the sprint before starting".', 'Viewer cannot drag; Reporter cannot start or delete sprints.'],
        ok=['Sprint totals always equal the sum of the points of its issues.', 'Only one sprint is active at a time.'])

section(9, 'Issues list and bulk changes', 'The table view with filters, sorting and multi-select', BLUE,
        'Everyone who can view the project; bulk edit needs edit rights', 'Project > Issues',
        ['Open Issues tab', 'Filter / sort', 'Tick rows', 'Use bulk bar', 'Result message'],
        [('Open ACME > Issues.', 'Table with Key, Summary, Status, Priority, Assignee, Due, Updated. Tabs show counts: All, To do, In progress, Done.'),
         ('Click the Status tab "In progress".', 'Only in-progress issues remain.'),
         ('Click a column header (e.g. Priority) once, twice, third time.', 'Ascending, descending, then original order.'),
         ('Choose Type = Bug and type text in Search.', 'Filters combine.'),
         ('Tick 3 rows.', 'A floating bar appears: "3 selected" with Set status, Assign to, Priority and Delete.'),
         ('Choose Priority > High.', 'Toast "3 issues updated" and rows show the new priority.'),
         ('Click a row.', 'Issue drawer opens.')],
        neg=['As a Reporter, bulk-changing issues you do not own gives a partial result such as "1 updated, 2 failed: You do not have permission".', 'Viewer sees no checkboxes.'],
        ok=['Bulk result messages always say how many succeeded and failed.'])

section(10, 'Timeline and reports', 'Roadmap of epics and the charts', PINK,
        'Everyone who can view the project', 'ACME > Timeline and ACME > Reports',
        ['Open Timeline', 'Zoom', 'Open Reports', 'Read charts'],
        [('Open ACME > Timeline.', 'One bar per epic (Authentication, Payments, Onboarding, Performance, Dark Mode) with a fill showing % of child issues done, sprint bands and a TODAY marker.'),
         ('Switch Weeks / Months / Quarters.', 'Bars rescale. Click a bar: the epic opens in a drawer.'),
         ('Open Reports.', 'Six tiles (Total, Open, Done, Overdue, Open bugs, Median cycle days) then Burndown, Velocity, Created vs resolved, Cumulative flow, By status / type / priority, Workload by assignee.'),
         ('Hover over chart points.', 'Tooltip shows exact values; charts animate in.'),
         ('Compare Velocity with the sprint headers.', 'Sprint 1-4 show committed vs completed (29, 32, 34, 36 completed); Sprint 5 is shown in amber because it is still running.'),
         ('Open Reports for MOB (Kanban).', 'No burndown or velocity (they are Scrum only); other charts still show.')],
        ok=['Numbers on the tiles match counts in the Issues list.', 'Empty projects show "No data yet" instead of broken charts.'])

section(11, 'Search with OQL and saved filters', 'Finding issues across projects', VIOLET,
        'Everyone (results contain only projects the user may view)', 'Sidebar > Filters',
        ['Type a query', 'Press Search', 'Open / bulk edit results', 'Save the filter', 'Re-use it'],
        [('Open Filters.', 'Default query shows your open issues. Example chips are listed under the box.'),
         ('Click the chip <font face="Courier">type = bug AND priority &gt;= High AND statusCategory != done</font>.', 'Results update and the count is shown ("n results").'),
         ('Type <font face="Courier">assignee = "Sara Dev" ORDER BY updated DESC</font> and press Enter.', 'Only Sara\'s issues, newest first.'),
         ('Try <font face="Courier">created &gt;= -7d AND assignee IS EMPTY</font>.', 'Issues created in the last 7 days with no assignee.'),
         ('Try <font face="Courier">text ~ "payment"</font>.', 'Issues mentioning payment in title or description.'),
         ('Press Save, name it "My QA filter", tick Share.', 'It appears in the right-hand Saved filters list; teammates see it too.'),
         ('Click a saved filter.', 'Query is loaded and run. The trash icon deletes your own filters.'),
         ('Select several results and use the bulk bar.', 'Same behaviour as in the Issues tab.')],
        neg=['<font face="Courier">foo = 1</font>: red message <i>Unknown field "foo"</i>.', 'Unclosed bracket or quote: a clear message such as "Missing )" or "Unterminated string".', 'Query for a project you cannot access (e.g. PLAT as Sara): zero results, no error.'],
        example=['status IN ("In Progress", "QA")', 'sprint IN openSprints()', 'due &lt; now() AND statusCategory != done', 'project = SUP AND priority = High'],
        ok=['Every example returns sensible results; errors never crash the page.'])

section(12, 'Automation rules', 'Rules that react when issues are created or change status', AMBER,
        'Project admins edit; everyone in the project can view', 'Project > Automation',
        ['Open Automation', 'Create rule', 'Trigger the event', 'Check run count'],
        [('Open ACME > Automation.', 'Two seeded rules with the WHEN > IF > THEN summary, run counts and an on/off switch.'),
         ('Click Create rule: name "Label QA items", When = status changes, Condition = new status is QA, Then = add label <b>needs-qa</b>.', 'Rule appears in the list and is enabled.'),
         ('On the board drag any issue into QA.', 'The issue receives the label needs-qa; the rule\'s run count goes up by one; the issue History shows "ran automation".'),
         ('Switch the rule off, repeat the drag.', 'No label is added.'),
         ('Delete the rule with the bin icon.', 'It disappears.')],
        neg=['Rule name shorter than 3 characters is rejected.', 'Developers (not admins) see the rules but have no create / delete / switch rights.'],
        ok=['Disabled rules never fire; enabled rules fire exactly once per event.'])

section(13, 'Notifications and inbox', 'Bell, inbox page and what triggers them', GREEN,
        'Everyone', 'Bell icon (top bar) and sidebar > Inbox',
        ['Do an action', 'Other user gets notice', 'Open bell', 'Click it', 'Marked read'],
        [('As Sara assign ACME-50 to Lena.', 'Lena\'s bell shows +1 within about 45 seconds (or on refresh): "Sara Dev assigned you ACME-50".'),
         ('As Sara comment with @Lena Fischer.', 'Lena gets a "mentioned you" notice (counts under the Mentions tab).'),
         ('As Priya start a sprint.', 'People with issues in it get "ACME Sprint 6 has started".'),
         ('As Lena open Inbox.', 'List with unread dot and blue tint; tabs All / Unread / Mentions.'),
         ('Click a notification.', 'Opens the issue and the unread dot disappears; sidebar badge decreases.'),
         ('Press Mark all read.', 'All dots clear and the badge disappears.')],
        neg=['You never receive a notification for your own action.'],
        ok=['Counts in the bell, the sidebar badge and the Inbox agree.'])

section(14, 'Goals and team workload', 'OKRs and capacity view', PINK,
        'Members (not Guests)', 'Sidebar > Goals and Workload',
        ['Open Goals', 'New goal', 'Update key result', 'Open Workload'],
        [('Open Goals.', 'Three seeded goals with a progress ring and key-result bars.'),
         ('As Marcus change the status dropdown of his goal to At risk.', 'Chip turns amber. Other users see the chip but cannot change it.'),
         ('Edit a key-result current value and click away.', 'Bar and the ring percentage update.'),
         ('Click New goal: objective, period, one key result with target 10.', 'Goal is added at the top.'),
         ('Open Workload.', 'One row per person with load % (green / amber / red), weekly hour cells for 4 weeks.')],
        neg=['Goal with no key result: "Add at least one key result".', 'Guest has no Goals menu item (and cannot create goals).'],
        ok=['Colours follow load: under 40% blue, up to 75% green, up to 100% amber, over 100% red with an "overloaded" note.'])

section(15, 'Project settings and members', 'Details, access, board limits, delete', BLUE,
        'Project admins (others see read-only)', 'Project > Settings',
        ['Open Settings', 'Edit details', 'Manage access', 'Set WIP limits', 'Delete (danger)'],
        [('Open ACME > Settings as Priya.', 'Tabs: Details, Access, Board & WIP, Danger zone.'),
         ('Change the description and Save changes.', 'Toast "Saved". The project key field is greyed out (cannot change).'),
         ('Access tab: choose a person not yet in the project, role Developer, Add.', 'They appear in the list; they get a "added you to the project" notification.'),
         ('Change someone\'s role with the dropdown.', 'Toast "Role updated"; their abilities change immediately on next page load.'),
         ('Board & WIP: set In Progress to 3 and save.', 'On the board the column shows "n / 3" and glows red above 3.'),
         ('Danger zone: Delete project, type the key to confirm.', 'Project disappears from lists and URLs show "Project not found".')],
        neg=['Remove or demote the only Project Admin: "A project needs at least one Project Admin".', 'Sara (Developer) opens Settings: banner "You have read-only access to these settings" and disabled fields.', 'Delete confirmation button stays disabled until the exact key is typed.'],
        ok=['Visibility Private hides the project from non-members at once.'])

section(16, 'Profile and password', 'My account settings', SLATE,
        'Everyone', 'Avatar menu > Profile & security',
        ['Open Settings', 'Edit profile', 'Change theme', 'Change password'],
        [('Open Profile & security.', 'Shows avatar, role and organization.'),
         ('Change name and job title, Save profile.', 'Toast "Profile updated"; the new name appears in the account menu after refresh.'),
         ('Click Light / Dark.', 'Theme switches immediately.'),
         ('Enter current password and a new one (10+ characters, a capital, a number), Update password.', 'Toast "Password changed - other sessions were signed out". You stay signed in; signing in on another browser with the old password fails.')],
        neg=['Wrong current password: "Current password is incorrect".', 'New password "short": "Use at least 10 characters".'],
        ok=['Old password stops working immediately after a change.'])

section(17, 'Organization admin console', 'Members, roles and audit trail for one organization', AMBER,
        'Org Admin only', 'Sidebar > Organization (admin@acme.dev)',
        ['Open Organization', 'Invite member', 'Change role', 'Deactivate', 'Read audit log'],
        [('Open Organization as Alex.', 'Members table with role dropdown, project chips, last active and status.'),
         ('Click Invite member: name "QA Tester", email qa.tester@acme.dev, role Member.', 'Dialog "Member invited" shows a one-time temporary password. Copy it.'),
         ('Sign in as the new user with that password.', 'Works; the user has no projects until added to one.'),
         ('Change a member\'s role to Guest.', 'Toast "Member updated"; that user loses Goals / Workload and sees only projects they belong to.'),
         ('Deactivate a member.', 'Status turns Deactivated; within about 10 seconds they are signed out and cannot log in again; their open issues become unassigned.'),
         ('Open the Audit log tab and type "member" in the filter.', 'Rows such as org.member_invited and org.member_updated with who and when.')],
        neg=['Demote or deactivate yourself: "You cannot demote or deactivate yourself".', 'Remove the last Org Admin: "The organization needs at least one admin".', 'Invite an existing email: "This email is already registered".', 'Sara opens /admin/org directly: 403 "Access denied" page.'],
        ok=['Every admin action appears in the audit log.'])

section(18, 'Super Admin platform console', 'All organizations, all users, impersonation', RED,
        'Super Admin only', 'Sidebar > Platform (superadmin@orbit.dev)',
        ['Open Platform', 'Overview', 'Create org', 'Manage users', 'Impersonate', 'Exit banner'],
        [('Sign in as Super Admin.', 'Overview tiles (Organizations, Users, Projects, Issues, Active 24h, Lockouts), 14-day chart, system health with a green "connected" dot.'),
         ('Organizations tab > New organization: "Initech", plan Pro, admin Bill / bill@initech.io.', 'Dialog shows the admin email and a one-time temporary password.'),
         ('Change a plan with the dropdown; Suspend an organization.', 'Toast "Organization updated". Users of a suspended organization are signed out of their current session.'),
         ('Users tab: search "sara", Manage > Reset password.', 'A temporary password is shown once.'),
         ('Manage > Suspend on a test user, then try to sign in as them.', 'Login refused with the suspended message.'),
         ('Manage > Impersonate on Sara; enter reason "Checking board issue".', 'Orange banner "Viewing as Sara Dev - every action is audited" with an Exit button; the app looks exactly as Sara sees it.'),
         ('Click Exit in the banner.', 'You return to the Platform console as Super Admin.'),
         ('Audit log tab.', 'Entries for impersonate_start / impersonate_end and the org creation.')],
        neg=['Impersonation reason shorter than 5 characters: "Give a short reason".', 'Cannot impersonate another Super Admin.', 'Cannot suspend yourself; cannot remove the last Super Admin ("There must be at least one Super Admin").', 'Org Admin opening /admin/platform gets "403 - Access denied".'],
        ok=['Impersonated actions are visible in the audit log with the Super Admin\'s name.'])

story.append(Band(19, 'Role permission test matrix', 'Run the same action with each account and compare', INK))
story.append(sp(8))
mat = [('Action in ACME', 'Priya (Admin)', 'Sara (Dev)', 'Tom (Reporter)', 'Vera (Viewer)', 'Guest'),
       ('See project', 'Yes', 'Yes', 'Yes', 'Yes', 'No (404)'),
       ('Create issue (C)', 'Yes', 'Yes', 'Yes', 'No', 'No'),
       ('Edit any issue', 'Yes', 'Yes', 'Own only', 'No', 'No'),
       ('Drag a card', 'Yes', 'Yes', 'Own only', 'No', 'No'),
       ('Assign issue', 'Yes', 'Yes', 'No', 'No', 'No'),
       ('Comment / log work', 'Yes', 'Yes', 'Comment', 'No', 'No'),
       ('Start / complete sprint', 'Yes', 'Yes', 'No', 'No', 'No'),
       ('Delete issue', 'Yes', 'No', 'No', 'No', 'No'),
       ('Project settings, members', 'Yes', 'Read-only', 'Read-only', 'Read-only', 'No'),
       ('Automation rules', 'Create', 'View', 'View', 'View', 'No'),
       ('See PLAT (private)', 'No', 'No', 'No', 'No', 'No (Alex yes)'),
       ('See SUP project', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes'),
       ('Admin pages', 'No', 'No', 'No', 'No', 'No')]
data = [[P(x, head) for x in mat[0]]]
for r in mat[1:]:
    row = [P(r[0], cellb)]
    for v in r[1:]:
        col = GREEN if v.startswith(('Yes', 'Create')) else (AMBER if v.startswith(('Own', 'Read', 'View', 'Comment')) else RED)
        row.append(P(f'<font color="#{col.hexval()[2:]}"><b>{v}</b></font>', S('mc', 8.4, align=TA_CENTER)))
    data.append(row)
t = Table(data, colWidths=[46 * mm, 25 * mm, 24 * mm, 26 * mm, 25 * mm, 24 * mm], repeatRows=1)
t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), INK), ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, mix(VIOLET, 0.06)]), ('BOX', (0, 0), (-1, -1), 0.6, LINE), ('LINEBELOW', (0, 0), (-1, -1), 0.4, LINE), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
story.append(t)
story.append(sp(8))
story.append(box('Data-separation checks', ['As Alex type /issues/GLX-1 (a Globex issue): "Issue not found" - it must behave as if it does not exist.', 'As Sara open /projects/PLAT/board: "Project not found".', 'As the Guest open /issues/ACME-50: "Issue not found"; Projects list shows only Customer Support.', 'As Sara open /admin/org or /admin/platform: "403 - Access denied".', 'Signed out, open any private address: redirected to login.'], RED))
story.append(PageBreak())

story.append(Band(20, 'Tester checklist and known limits', 'Tick as you go, report anything that differs from "what should happen"', INK))
story.append(sp(8))
checks = ['1 Sign in / out for all 9 accounts', '2 Navigation, Ctrl+K palette, theme toggle, shortcuts', '3 Dashboard tiles, focus timer, sprint card', '4 Projects: search, star, create wizard (valid + invalid key)', '5 Create issue incl. quick capture and Create another', '6 Issue page: status, fields, comment with @mention, work log, sub-task, delete', '7 Board: drag, Done pulse, WIP limit, swimlanes, only-mine, complete sprint', '8 Backlog: create sprint, drag, suggest, start (all error cases)', '9 Issues list: filters, sort, bulk change', '10 Timeline and Reports for ACME and MOB', '11 OQL search, error messages, save and delete a filter', '12 Automation: create, fire, disable, delete', '13 Notifications: bell, inbox, mark all read', '14 Goals and Workload', '15 Project settings: members, last-admin rule, WIP, delete', '16 Profile and password change', '17 Org admin: invite, role, deactivate, audit', '18 Super Admin: create org, suspend, impersonate, exit', '19 Permission matrix and data-separation checks', '20 Both themes and a narrow (phone) window on Dashboard and Board']
data = [[P('[  ]', cellb), P(c_)] for c_ in checks]
t = Table(data, colWidths=[12 * mm, 158 * mm]); t.setStyle(TableStyle([('ROWBACKGROUNDS', (0, 0), (-1, -1), [white, mix(GREEN, 0.07)]), ('BOX', (0, 0), (-1, -1), 0.6, LINE), ('LINEBELOW', (0, 0), (-1, -1), 0.4, LINE), ('TOPPADDING', (0, 0), (-1, -1), 4), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
story.append(t); story.append(sp(8))
story.append(box('Things that are intentionally NOT in this version (do not report as bugs)', ['No e-mail is sent: invited users receive a temporary password shown on screen instead.', 'Notifications refresh about every 45 seconds (or on page refresh), not instantly.', 'Descriptions and comments use simple formatting (bold, code, bullet and checkbox lines), not a full rich-text editor.', 'No visual workflow designer and no customer self-service portal for the Support project.', 'Status labels on cards are shown in capital letters by design.', 'The Demo accounts panel on the login page is for testing only.', 'Suspending a whole organization signs its users out, but does not yet stop them from signing in again (suspend individual users to block login).'], AMBER))
story.append(sp(8))
story.append(box('When you find a problem please note', ['Account used, page address, and the exact steps.', 'What you expected (from the "what should happen" column) and what you saw.', 'A screenshot, and whether it happens in both dark and light theme.'], BLUE))

# ------------------------------------------------------------------ build
def deco(c, doc):
    c.saveState()
    c.setFillColor(BG); c.rect(0, 0, W, H, stroke=0, fill=1)
    c.setFillColor(VIOLET); c.rect(0, H - 4, W / 2, 4, stroke=0, fill=1); c.setFillColor(CYAN); c.rect(W / 2, H - 4, W / 2, 4, stroke=0, fill=1)
    c.setFillColor(SLATE); c.setFont('Helvetica', 7.5); c.drawString(18 * mm, 9 * mm, 'Team Sprint  |  QA User Flow Guide'); c.drawRightString(W - 18 * mm, 9 * mm, f'Page {doc.page}')
    c.restoreState()
doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=14 * mm, bottomMargin=16 * mm, title='Team Sprint - QA User Flow Guide', author='Team Sprint')
doc.addPageTemplates([PageTemplate(id='p', frames=[Frame(18 * mm, 16 * mm, W - 36 * mm, H - 30 * mm, id='f', leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)], onPage=deco)])
doc.build(story)
print('saved', OUT)
