import io
def rd(p): return open(p, encoding='utf8').read()
def wr(p, s): open(p, 'w', encoding='utf8').write(s)

# 1. Shell padding override
p = 'src/components/Shell.tsx'; s = rd(p)
s = s.replace("<motion.div animate={{ paddingLeft: 0 }} className=", "<div className=")
s = s.replace("</main>\n        </motion.div>\n      </div>", "</main>\n        </div>\n      </div>")
wr(p, s)

# 2. Select -> custom listbox
p = 'src/components/ui.tsx'; s = rd(p)
a = s.index("export function Select(")
s = s[:a] + rd('.data/select_snippet.tsx')
s = s.replace("import { useEffect, useId, useRef, useState, type ReactNode, type MouseEvent } from 'react';", "import { useEffect, useId, useRef, useState, type ReactNode, type MouseEvent } from 'react';\nimport { createPortal } from 'react-dom';")
s = s.replace("X, Bug,", "X, Check, ChevronDown, Search as SearchIcon, Bug,")
wr(p, s)

# 3. CSS
p = 'src/app/globals.css'; s = rd(p)
s = s.replace(".input { width: 100%; height: 40px; padding: 0 12px; border-radius: 12px;", ".input { width: 100%; height: 40px; padding: 0 12px; border-radius: 8px;")
s = s.replace("textarea.input { height: auto; padding: 10px 12px; resize: vertical; line-height: 1.55; }", "textarea.input { height: auto; min-height: 104px; padding: 10px 12px; resize: vertical; line-height: 1.55; }")
s = s.replace(".label { display: block; margin-bottom: 6px; font-size: 12px; font-weight: 600; color: var(--text-muted); letter-spacing: 0.02em; }", ".label { display: block; margin-bottom: 6px; font-size: 13px; font-weight: 600; line-height: 1; color: var(--text); opacity: .85; }")
wr(p, s)

# 4. unstable [] fallback
for p in ['src/app/(app)/projects/[key]/backlog/page.tsx', 'src/app/(app)/projects/[key]/board/page.tsx', 'src/app/(app)/projects/[key]/list/page.tsx']:
    s = rd(p)
    s = s.replace("const all = data?.items || [];", "const all = useMemo(() => data?.items ?? [], [data]);")
    wr(p, s)

# 5. CreateIssueModal defaults loop
p = 'src/components/issue/CreateIssueModal.tsx'; s = rd(p)
s = s.replace("}, [open, projectKey, defaults]);", "  // eslint-disable-next-line react-hooks/exhaustive-deps\n  }, [open, projectKey, JSON.stringify(defaults ?? {})]);")
wr(p, s)

# 6. raw selects -> Select
p = 'src/app/(app)/projects/[key]/backlog/page.tsx'; s = rd(p)
s = s.replace('<select aria-label="Epic filter" className="input !h-9 !w-52" value={epicF} onChange={(e) => setEpicF(e.target.value)}><option value="">All epics</option>{epics.map((e) => <option key={e._id} value={e._id}>{e.summary}</option>)}</select>', "<Select aria-label=\"Epic filter\" className=\"!w-56\" value={epicF} onChange={setEpicF} options={[{ value: '', label: 'All epics' }, ...epics.map((e) => ({ value: e._id, label: e.summary }))]} />")
s = s.replace("import { Avatar, Card, ConfirmDialog, Field, Modal,", "import { Avatar, Card, ConfirmDialog, Field, Modal, Select,")
wr(p, s)

p = 'src/app/(app)/projects/page.tsx'; s = rd(p)
s = s.replace('<select className="input" value={f.visibility} onChange={(e) => setF({ ...f, visibility: e.target.value })} aria-label="Visibility"><option value="org">Everyone in the organization</option><option value="private">Private — members only</option></select>', "<Select aria-label=\"Visibility\" value={f.visibility} onChange={(v) => setF({ ...f, visibility: v })} options={[{ value: 'org', label: 'Everyone in the organization' }, { value: 'private', label: 'Private — members only' }]} />")
s = s.replace("import { Avatar, Card, EmptyState, Field, Modal,", "import { Avatar, Card, EmptyState, Field, Modal, Select,")
wr(p, s)

p = 'src/components/FocusTimer.tsx'; s = rd(p)
s = s.replace('<select aria-label="Duration" className="input !h-9 !w-[84px]" value={minutes} onChange={(e) => { setMinutes(+e.target.value); setLeft(+e.target.value * 60); }}>{[15, 25, 45, 60].map((m) => <option key={m} value={m}>{m}m</option>)}</select>', "<Select aria-label=\"Duration\" className=\"!w-[92px]\" value={String(minutes)} onChange={(v) => { setMinutes(+v); setLeft(+v * 60); }} options={[15, 25, 45, 60].map((m) => ({ value: String(m), label: m + 'm' }))} />")
wr(p, s)

# 7. dashboard hydration
p = 'src/app/(app)/dashboard/page.tsx'; s = rd(p)
s = s.replace("const hour = new Date().getHours();\n  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';", "const [now, setNow] = useState<Date | null>(null);\n  useEffect(() => setNow(new Date()), []);\n  const hour = now?.getHours() ?? 12;\n  const greet = !now ? 'Welcome' : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';")
s = s.replace("{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}", "{now ? now.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' }) : ' '}")
s = s.replace("import Link from 'next/link';", "import { useEffect, useState } from 'react';\nimport Link from 'next/link';", 1)
wr(p, s)
print('done')
