import { parse, compile } from '../src/server/oql';
const r:any={userId:'x',user:async()=>null,project:async()=>null,sprint:async()=>[]};
(async()=>{ const q=parse('foo = 1'); console.log(JSON.stringify(q)); try{console.log(JSON.stringify(await compile(q,r)))}catch(e:any){console.log('ERR',e.message)} })();
