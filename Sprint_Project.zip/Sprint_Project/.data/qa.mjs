import { chromium } from 'playwright';
const base = 'http://localhost:7000';
const browser = await chromium.launch();
const results = [];
async function session(email, pw, pages, tag, viewport = { width: 1440, height: 900 }) {
  const ctx = await browser.newContext({ viewport });
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', (m) => { if (['error'].includes(m.type())) errs.push(m.text().slice(0, 200)); });
  page.on('pageerror', (e) => errs.push('PAGEERR ' + e.message.slice(0, 200)));
  page.on('response', (r) => { if (r.status() >= 500) errs.push(`HTTP ${r.status()} ${r.url()}`); });
  await page.goto(base + '/login');
  await page.fill('#email', email); await page.fill('#password', pw);
  await page.click('button:has-text("Sign in")');
  await page.waitForURL((u) => !u.pathname.startsWith('/login'), { timeout: 20000 });
  for (const p of pages) {
    errs.length = 0;
    await page.goto(base + p, { waitUntil: 'networkidle', timeout: 45000 }).catch(() => {});
    await page.waitForTimeout(1300);
    const name = tag + p.replace(/[^a-z0-9]+/gi, '_');
    await page.screenshot({ path: `.data/shots/${name}.png` });
    const body = (await page.locator('body').innerText()).slice(0, 4000);
    const bad = /Something went wrong|Could not load|Application error|Unhandled/i.test(body);
    results.push({ tag, p, errs: [...errs], bad });
  }
  await ctx.close();
}
await session('sara.dev@acme.dev', 'Orbit@Demo123!', ['/dashboard', '/projects', '/projects/ACME/board', '/projects/ACME/backlog', '/projects/ACME/list', '/projects/ACME/timeline', '/projects/ACME/reports', '/projects/ACME/automation', '/projects/ACME/settings', '/issues/ACME-50', '/search', '/notifications', '/goals', '/workload', '/settings', '/projects/MOB/board', '/projects/SUP/board', '/projects/MKT/board', '/admin/org'], 'dev');
await session('superadmin@orbit.dev', 'Orbit@Super123!', ['/admin/platform'], 'sa');
await session('admin@acme.dev', 'Orbit@Admin123!', ['/admin/org', '/projects/PLAT/board'], 'adm');
await session('sara.dev@acme.dev', 'Orbit@Demo123!', ['/dashboard'], 'mob', { width: 390, height: 844 });
for (const r of results) console.log((r.errs.length || r.bad ? 'FAIL ' : 'ok   ') + r.tag + ' ' + r.p + (r.bad ? ' [error text]' : '') + (r.errs.length ? ' ' + JSON.stringify(r.errs.slice(0, 3)) : ''));
await browser.close();
