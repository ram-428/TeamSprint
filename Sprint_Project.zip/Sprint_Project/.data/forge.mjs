import { SignJWT } from 'jose';
const secret = new TextEncoder().encode('team-sprint-dev-secret-change-me-in-production-32chars');
console.log(await new SignJWT({ uid: '6b041a14a11231abefe8ffff', tv: 0 }).setProtectedHeader({ alg: 'HS256' }).setExpirationTime('7d').sign(secret));
