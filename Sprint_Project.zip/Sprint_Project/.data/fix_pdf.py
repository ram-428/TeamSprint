p = '.data/make_pdf.py'
s = open(p, encoding='utf8').read()
def rep(a, b, cnt=1):
    global s
    assert a in s, a[:60]
    s = s.replace(a, b, cnt)

# p3: stray arrow + callouts higher
rep("arrow(810, H - 135, 810, H - 135, GREEN)\n", "")
rep("callout(34, 40, 380, 92, 'Why a monolith?'", "callout(34, 120, 380, 92, 'Why a monolith?'")
rep("callout(430, 40, 380, 92, 'Speed measures built in'", "callout(430, 120, 380, 92, 'Speed measures built in'")

# p4: viewer text shorter
rep("'Read-only: no create button, drag disabled, API returns 403'", "'Read-only: no create, no drag; API gives 403'")

# p6: validation callout lower
rep("callout(430, H - 365 + 0, 380, 105, 'Validation you will actually see'", "callout(430, H - 470, 380, 105, 'Validation you will actually see'")

# p7: callout below the code block
rep("callout(380, H - 430, 430, 94, 'Business rules enforced by the server'", "callout(380, H - 478, 430, 100, 'Business rules enforced by the server'")

# p8: drag card over the In Review column
rep("c.saveState(); c.translate(250, H - 178); c.rotate(-4)", "c.saveState(); c.translate(346, H - 196); c.rotate(-4)")
rep("arrow(318, H - 150, 408, H - 150, VIOLET, lw=2.4, label='drag', ly=6)", "arrow(318, H - 138, 344, H - 138, VIOLET, lw=2.4)\nc.setFillColor(VIOLET); c.setFont('Helvetica-Bold', 8); c.drawString(322, H - 128, 'drag')")

# p9: shift charts up, add example callout
rep("# burndown chart mock\ncx0, cy0, cw_, ch_ = 56, 80, 360, 190", "# burndown chart mock\nc.saveState(); c.translate(0, 34)\ncx0, cy0, cw_, ch_ = 56, 80, 360, 190")
rep("chip(468, 250, 'committed', SLATE, fs=7); chip(530, 250, 'completed', CYAN, fs=7)", "chip(468, 250, 'committed', SLATE, fs=7); chip(530, 250, 'completed', CYAN, fs=7)\nc.restoreState()\ncallout(34, 24, W - 68, 46, 'Reading the numbers', 'Sprint 5 committed <b>35 pts</b>; on day 6, <b>20 pts</b> are done (57%) and <b>15 pts</b> remain, slightly ahead of the ideal line. Average velocity of Sprints 1-4 is <b>33 pts</b>, which the planning assistant uses to suggest how many issues fit Sprint 6.', VIOLET)")

# p10: reference spacing
rep("c.drawString(34, 192, 'Reference')\nref =", "c.drawString(34, 178, 'Reference')\nref =")
rep("yy = 176\nfor k, v in ref:\n    chip(34, yy - 4, k, VIOLET, w=84, fs=7.6); para(v, 128, yy + 6, 680, style(8.4, INK, lead=10)); yy -= 22", "yy = 160\nfor k, v in ref:\n    chip(34, yy - 4, k, VIOLET, w=84, fs=7.6); para(v, 128, yy + 6, 680, style(8.4, INK, lead=10)); yy -= 19")
rep("callout(34, 34, W - 68, 46, 'After searching'", "callout(30, 22, W - 60, 40, 'After searching'")
open(p, 'w', encoding='utf8').write(s)
print('patched')
