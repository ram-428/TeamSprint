def rd(p): return open(p, encoding='utf8').read()
def wr(p, s): open(p, 'w', encoding='utf8').write(s)

# --- 1. user cache in getUser (10s TTL, keyed by uid+tokenVersion) ---
p = 'src/server/auth.ts'; s = rd(p)
s = s.replace("/** Resolves the logged-in user", """const userCache = new Map<string, { at: number; u: AuthUser | null }>();
export const dropUserCache = (id?: string) => (id ? userCache.delete(id) : userCache.clear());

/** Resolves the logged-in user""")
s = s.replace("""  await connectDB();
  const u = await User.findById(s.uid).lean<any>();
  if (!u || u.status !== 'active' || (u.tokenVersion ?? 0) !== (s.tv ?? 0)) return null;
  return {""", """  const ck = `${s.uid}:${s.tv ?? 0}:${s.imp ?? ''}`;
  const hit = userCache.get(ck);
  if (hit && Date.now() - hit.at < 10_000) return hit.u;
  await connectDB();
  const u = await User.findById(s.uid).select('name email orgId role platformRole title color theme status tokenVersion').lean<any>();
  if (!u || u.status !== 'active' || (u.tokenVersion ?? 0) !== (s.tv ?? 0)) { userCache.set(ck, { at: Date.now(), u: null }); return null; }
  const res: AuthUser = {""")
s = s.replace("""    impersonatedBy: s.imp,
  };
}""", """    impersonatedBy: s.imp,
  };
  userCache.set(ck, { at: Date.now(), u: res });
  if (userCache.size > 500) userCache.clear();
  return res;
}""")
wr(p, s)

# --- 2. light issue list (no description) ---
p = 'src/app/api/issues/route.ts'; s = rd(p)
s = s.replace("const items = await Issue.find(filter).sort({ rank: 1 }).limit(1000).lean<any[]>();", "const items = await Issue.find(filter).select('-description -watchers -votes -orgId').sort({ rank: 1 }).limit(1000).lean<any[]>();")
wr(p, s)
p = 'src/server/query.ts'; s = rd(p)
s = s.replace("Issue.find(filter).sort(sort)", "Issue.find(filter).select('-description -watchers -votes -orgId').sort(sort)")
wr(p, s)

# --- 3. indexes ---
p = 'src/server/models.ts'; s = rd(p)
s = s.replace("issueSchema.index({ summary: 'text', description: 'text' });", """issueSchema.index({ summary: 'text', description: 'text' });
issueSchema.index({ projectId: 1, deletedAt: 1, rank: 1 });
issueSchema.index({ projectId: 1, sprintId: 1, deletedAt: 1 });
issueSchema.index({ assigneeId: 1, statusCategory: 1, deletedAt: 1, dueDate: 1 });
issueSchema.index({ projectId: 1, statusCategory: 1, resolvedAt: 1 });
issueSchema.index({ orgId: 1, key: 1 }, { unique: true });
issueSchema.index({ epicId: 1 }); issueSchema.index({ parentId: 1 });""")
s = s.replace("export const Comment = model<any>('Comment', new Schema({\n  orgId: oid, issueId: { type: oid, index: true }, authorId: oid, body: String, internal: Boolean, mentions: [oid],\n}, opts));", "const commentSchema = new Schema({\n  orgId: oid, issueId: { type: oid, index: true }, authorId: oid, body: String, internal: Boolean, mentions: [oid],\n}, opts);\ncommentSchema.index({ issueId: 1, createdAt: 1 });\nexport const Comment = model<any>('Comment', commentSchema);")
s = s.replace("export const Notification = model<any>('Notification', new Schema({\n  userId: { type: oid, index: true }, actorId: oid, type: String, message: String, issueKey: String, readAt: Date,\n}, opts));", "const notifSchema = new Schema({\n  userId: { type: oid, index: true }, actorId: oid, type: String, message: String, issueKey: String, readAt: Date,\n}, opts);\nnotifSchema.index({ userId: 1, createdAt: -1 }); notifSchema.index({ userId: 1, readAt: 1 });\nexport const Notification = model<any>('Notification', notifSchema);")
s = s.replace("export const Audit = model<any>('Audit', new Schema({\n  orgId: oid, actorId: oid, impersonatedBy: oid, action: String, target: String, ip: String, meta: Schema.Types.Mixed,\n}, opts));", "const auditSchema = new Schema({\n  orgId: oid, actorId: oid, impersonatedBy: oid, action: String, target: String, ip: String, meta: Schema.Types.Mixed,\n}, opts);\nauditSchema.index({ orgId: 1, createdAt: -1 }); auditSchema.index({ action: 1, createdAt: -1 }); auditSchema.index({ createdAt: -1 });\nexport const Audit = model<any>('Audit', auditSchema);")
s = s.replace("export const Worklog = model<any>('Worklog', new Schema({ orgId: oid, issueId: { type: oid, index: true }, userId: oid, seconds: Number, startedAt: Date, description: String }, opts));", "const worklogSchema = new Schema({ orgId: oid, issueId: { type: oid, index: true }, userId: oid, seconds: Number, startedAt: Date, description: String }, opts);\nworklogSchema.index({ userId: 1, startedAt: -1 });\nexport const Worklog = model<any>('Worklog', worklogSchema);")
s = s.replace("export const Activity = model<any>('Activity', new Schema({\n  orgId: oid, projectId: { type: oid, index: true }, issueId: { type: oid, index: true }, actorId: oid, action: String,\n  diff: Schema.Types.Mixed, meta: Schema.Types.Mixed,\n}, opts));", "const activitySchema = new Schema({\n  orgId: oid, projectId: { type: oid, index: true }, issueId: { type: oid, index: true }, actorId: oid, action: String,\n  diff: Schema.Types.Mixed, meta: Schema.Types.Mixed,\n}, opts);\nactivitySchema.index({ projectId: 1, createdAt: -1 }); activitySchema.index({ issueId: 1, createdAt: -1 });\nexport const Activity = model<any>('Activity', activitySchema);")
s = s.replace("export const Sprint = model<any>('Sprint', new Schema({", "const sprintSchema = new Schema({")
s = s.replace("  retro: { wentWell: [String], improve: [String], actions: [String] },\n}, opts));", "  retro: { wentWell: [String], improve: [String], actions: [String] },\n}, opts);\nsprintSchema.index({ projectId: 1, state: 1 });\nexport const Sprint = model<any>('Sprint', sprintSchema);")
wr(p, s)

# --- 4. connection pool tuning ---
p = 'src/server/db.ts'; s = rd(p)
s = s.replace("serverSelectionTimeoutMS: 15000 }", "serverSelectionTimeoutMS: 15000, maxPoolSize: 20, minPoolSize: 4, retryReads: true }")
wr(p, s)

# --- 5. dedupe polling + quicker route transition ---
p = 'src/components/Shell.tsx'; s = rd(p)
s = s.replace("{ refreshMs: 20000 });\n  return enabled ? data?.unread || 0 : 0;", "{ refreshMs: 45000 });\n  return enabled ? data?.unread || 0 : 0;")
s = s.replace("'/api/notifications?limit=8', { refreshMs: 20000 }", "'/api/notifications?limit=8', { refreshMs: 45000 }")
s = s.replace("initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.28, ease: 'easeOut' }}", "initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.16, ease: 'easeOut' }}")
wr(p, s)

# --- 6. layout: org name via cached lookup ---
p = 'src/app/(app)/layout.tsx'; s = rd(p)
s = s.replace("  await connectDB();\n  const org = user.orgId ? await Org.findById(user.orgId).select('name').lean<any>() : null;\n  return <Shell me={{ ...user, orgName: org?.name }}>{children}</Shell>;", "  const orgName = user.orgId ? await orgNameOf(user.orgId) : undefined;\n  return <Shell me={{ ...user, orgName }}>{children}</Shell>;")
s = s.replace("export const dynamic = 'force-dynamic';", """export const dynamic = 'force-dynamic';

const orgNames = new Map<string, string>();
async function orgNameOf(id: string) {
  const hit = orgNames.get(id); if (hit) return hit;
  await connectDB();
  const org = await Org.findById(id).select('name').lean<any>();
  if (org?.name) orgNames.set(id, org.name);
  return org?.name as string | undefined;
}""")
wr(p, s)
print('ok')
