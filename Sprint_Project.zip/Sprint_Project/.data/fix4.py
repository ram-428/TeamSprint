def rd(p): return open(p, encoding='utf8').read()
def wr(p, s): open(p, 'w', encoding='utf8').write(s)

p = 'src/app/api/projects/route.ts'; s = rd(p)
a = s.index("  const counts = await Issue.aggregate([")
b = s.index("  return visible.map((p) => {")
s = s[:a] + """  const [counts, sprints, leads] = await Promise.all([
    Issue.aggregate([
      { $match: { projectId: { $in: ids }, deletedAt: null } },
      { $group: { _id: '$projectId', total: { $sum: 1 }, done: { $sum: { $cond: [{ $eq: ['$statusCategory', 'done'] }, 1, 0] } } } },
    ]),
    Sprint.find({ projectId: { $in: ids }, state: 'active' }).select('projectId name endDate').lean<any[]>(),
    User.find({ _id: { $in: visible.map((p) => p.leadId).filter(Boolean) } }).select('name color').lean<any[]>(),
  ]);
""" + s[b:]
wr(p, s)

p = 'src/app/api/dashboard/route.ts'; s = rd(p)
a = s.index("  const sprintStats = await Promise.all(")
b = s.index("  return {\n    mine:")
s = s[:a] + """  const [sprintIssues, sprintProjects, actIssues, actors] = await Promise.all([
    sprints.length ? Issue.find({ sprintId: { $in: sprints.map((s) => s._id) }, deletedAt: null }).select('sprintId points statusCategory').lean<any[]>() : [],
    Project.find({ _id: { $in: sprints.map((s) => s.projectId) } }).select('key name color').lean<any[]>(),
    Issue.find({ _id: { $in: acts.map((a) => a.issueId) } }).select('key summary').lean<any[]>(),
    User.find({ _id: { $in: acts.map((a) => a.actorId) } }).select('name color').lean<any[]>(),
  ]);
  const sprintStats = sprints.map((s) => {
    const items = sprintIssues.filter((i) => String(i.sprintId) === String(s._id));
    const total = items.reduce((a, i) => a + (i.points || 0), 0), done = items.filter((i) => i.statusCategory === 'done').reduce((a, i) => a + (i.points || 0), 0);
    const p = sprintProjects.find((x) => String(x._id) === String(s.projectId));
    return { _id: s._id, name: s.name, project: p, total, done, endDate: s.endDate, daysLeft: Math.max(0, Math.ceil((+s.endDate - Date.now()) / 864e5)) };
  });
""" + s[b:]
wr(p, s)
print('ok')
