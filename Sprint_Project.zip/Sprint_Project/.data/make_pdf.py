from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, white, Color
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER

W, H = landscape(A4)
OUT = r'D:\PROJECTS\EYE_CARE\Sprint_Project\Team_Sprint_Flow_Guide.pdf'

# palette (matches the app)
INK = HexColor('#14183a'); MUTED = HexColor('#5b6389'); LINE = HexColor('#d9dcf0')
VIOLET = HexColor('#6a47f5'); CYAN = HexColor('#0ea5c6'); PINK = HexColor('#e0559a'); GREEN = HexColor('#10a874')
AMBER = HexColor('#d98e04'); RED = HexColor('#e04848'); BLUE = HexColor('#2f7de1'); SLATE = HexColor('#8a91b3')
BG = HexColor('#f6f7fd'); CARD = white
def tint(c, a=0.12): return Color(c.red, c.green, c.blue, alpha=a)
def mix(c, a=0.12):  # blend with white (opaque)
    return Color(1 - (1 - c.red) * a, 1 - (1 - c.green) * a, 1 - (1 - c.blue) * a)

c = canvas.Canvas(OUT, pagesize=(W, H))
c.setTitle('Team Sprint - Overall Flow Guide'); c.setAuthor('Team Sprint')
page_no = [0]

def style(size=9.5, color=INK, bold=False, align=TA_LEFT, lead=None):
    return ParagraphStyle('s', fontName='Helvetica-Bold' if bold else 'Helvetica', fontSize=size, leading=lead or size * 1.32, textColor=color, alignment=align)

def para(text, x, ytop, w, st):
    p = Paragraph(text, st); _, h = p.wrap(w, 1000); p.drawOn(c, x, ytop - h); return h

def box(x, y, w, h, fill=CARD, stroke=LINE, r=10, lw=1, shadow=True):
    if shadow:
        c.setFillColor(Color(0.2, 0.2, 0.5, alpha=0.06)); c.roundRect(x + 2, y - 3, w, h, r, stroke=0, fill=1)
    c.setFillColor(fill); c.setStrokeColor(stroke); c.setLineWidth(lw); c.roundRect(x, y, w, h, r, stroke=1, fill=1)

def node(x, y, w, h, title, sub=None, color=VIOLET, icon=None, fill=None):
    box(x, y, w, h, fill=fill or mix(color, 0.10), stroke=color, r=10, lw=1.2)
    c.setFillColor(color); c.circle(x + 12, y + h - 13, 4.5, stroke=0, fill=1)
    c.setFillColor(INK); c.setFont('Helvetica-Bold', 9.5)
    ty = y + h - 17
    c.drawString(x + 22, ty, title)
    if sub:
        para(sub, x + 10, y + h - 24, w - 20, style(8, MUTED, lead=10.2))

def arrow(x1, y1, x2, y2, color=SLATE, lw=1.6, label=None, dash=False, lx=0, ly=0):
    c.setStrokeColor(color); c.setFillColor(color); c.setLineWidth(lw)
    if dash: c.setDash(4, 3)
    c.line(x1, y1, x2, y2); c.setDash()
    import math
    a = math.atan2(y2 - y1, x2 - x1); s = 6
    p = c.beginPath(); p.moveTo(x2, y2)
    p.lineTo(x2 - s * math.cos(a - 0.4), y2 - s * math.sin(a - 0.4)); p.lineTo(x2 - s * math.cos(a + 0.4), y2 - s * math.sin(a + 0.4)); p.close(); c.drawPath(p, stroke=0, fill=1)
    if label:
        c.setFont('Helvetica-Oblique', 7.5); c.setFillColor(MUTED); c.drawCentredString((x1 + x2) / 2 + lx, (y1 + y2) / 2 + 4 + ly, label)

def chip(x, y, text, color=VIOLET, w=None, fs=7.8):
    w = w or (c.stringWidth(text, 'Helvetica-Bold', fs) + 14)
    c.setFillColor(mix(color, 0.14)); c.setStrokeColor(color); c.setLineWidth(0.7); c.roundRect(x, y, w, 14, 7, stroke=1, fill=1)
    c.setFillColor(color); c.setFont('Helvetica-Bold', fs); c.drawCentredString(x + w / 2, y + 4.3, text); return w

def header(title, sub=None, num=None):
    page_no[0] += 1
    c.setFillColor(BG); c.rect(0, 0, W, H, stroke=0, fill=1)
    # top band
    c.setFillColor(INK); c.rect(0, H - 58, W, 58, stroke=0, fill=1)
    g = c.beginPath(); g.rect(0, H - 58, W, 4); c.setFillColor(VIOLET); c.rect(0, H - 58, W * 0.5, 3, stroke=0, fill=1); c.setFillColor(CYAN); c.rect(W * 0.5, H - 58, W * 0.5, 3, stroke=0, fill=1)
    c.setFillColor(white); c.setFont('Helvetica-Bold', 19); c.drawString(34, H - 36, title)
    if sub: c.setFont('Helvetica', 9.5); c.setFillColor(HexColor('#b6bcf0')); c.drawString(34, H - 51, sub)
    if num: c.setFillColor(VIOLET); c.circle(W - 40, H - 30, 14, stroke=0, fill=1); c.setFillColor(white); c.setFont('Helvetica-Bold', 12); c.drawCentredString(W - 40, H - 34, str(num))
    c.setFillColor(SLATE); c.setFont('Helvetica', 7.5); c.drawString(34, 16, 'Team Sprint  |  Overall Flow Guide'); c.drawRightString(W - 34, 16, f'Page {page_no[0]}')

def callout(x, y, w, h, title, text, color=GREEN):
    box(x, y, w, h, fill=mix(color, 0.09), stroke=color, r=9, shadow=False)
    c.setFillColor(color); c.rect(x, y + 6, 3.5, h - 12, stroke=0, fill=1)
    c.setFont('Helvetica-Bold', 8.5); c.setFillColor(color); c.drawString(x + 12, y + h - 15, title)
    para(text, x + 12, y + h - 20, w - 22, style(8.2, INK, lead=10.6))

def step(n, x, y, color=VIOLET):
    c.setFillColor(color); c.circle(x, y, 9, stroke=0, fill=1); c.setFillColor(white); c.setFont('Helvetica-Bold', 9); c.drawCentredString(x, y - 3.2, str(n))

def mono(x, ytop, w, lines, fs=7.8, fill=HexColor('#10142c')):
    h = len(lines) * 11 + 14
    box(x, ytop - h, w, h, fill=fill, stroke=fill, r=8, shadow=False)
    y = ytop - 14
    for ln in lines:
        col = HexColor('#9fb0ff') if ln.startswith('#') or ln.startswith('//') else HexColor('#e8ecff')
        c.setFillColor(col); c.setFont('Courier', fs); c.drawString(x + 10, y, ln); y -= 11
    return h

# ============================ 1. COVER ============================
page_no[0] += 1
c.setFillColor(INK); c.rect(0, 0, W, H, stroke=0, fill=1)
for i, (cx, cy, r, col) in enumerate([(130, 470, 210, VIOLET), (720, 120, 240, CYAN), (520, 520, 150, PINK)]):
    for k in range(8):
        c.setFillColor(Color(col.red, col.green, col.blue, alpha=0.035)); c.circle(cx, cy, r - k * 22, stroke=0, fill=1)
c.setFillColor(white); c.roundRect(52, H - 150, 170, 80, 16, stroke=0, fill=1)
try:
    c.drawImage(r'D:\PROJECTS\EYE_CARE\Sprint_Project\public\brand\logo-full.png', 58, H - 146, width=158, height=72, preserveAspectRatio=True, mask='auto')
except Exception: pass
c.setFillColor(white); c.setFont('Helvetica-Bold', 46); c.drawString(52, H - 250, 'Overall Flow Guide')
c.setFont('Helvetica', 17); c.setFillColor(HexColor('#b6bcf0')); c.drawString(52, H - 280, 'How Team Sprint works - from sign-in to shipped sprint,')
c.drawString(52, H - 302, 'explained visually, step by step, with real sample data.')
x = 52
for t, col in [('Next.js 15', VIOLET), ('MongoDB Atlas', GREEN), ('Role-based access', CYAN), ('Sprints & Boards', PINK), ('OQL Search', AMBER)]:
    x += chip(x, H - 345, t, col, fs=9) + 8
c.setFillColor(HexColor('#8d94c9')); c.setFont('Helvetica', 10)
c.drawString(52, 70, 'Sample project used throughout:  ACME - "Team Sprint Web App"   |   Sample users: Priya (Scrum Master), Sara (Developer), Lena (QA)')
c.drawString(52, 52, 'App: http://localhost:7000   |   Database: team-sprint (MongoDB Atlas)')
c.showPage()

# ============================ 2. WHAT IS IT / MODULES ============================
header('1.  What Team Sprint does', 'One workspace for planning, tracking and shipping work - the whole product at a glance', 1)
mods = [
    ('Dashboard "For you"', 'Your open issues, due dates, sprint progress, focus timer, recent activity.', VIOLET),
    ('Projects', 'Scrum, Kanban, Business and Service-desk projects with a 3-step creation wizard.', CYAN),
    ('Issues', 'Epics, stories, tasks, bugs, sub-tasks. Inline edit, comments, history, work log.', PINK),
    ('Board', 'Drag & drop Kanban with WIP limits, swimlanes, flagged and aging cards.', GREEN),
    ('Backlog & Sprints', 'Plan sprints by dragging, start / complete, velocity-based suggestions.', AMBER),
    ('Timeline', 'Epic bars with child-issue progress, sprint bands and a today line.', BLUE),
    ('Reports', 'Burndown, velocity, created vs resolved, cumulative flow, distributions.', VIOLET),
    ('OQL Search', 'JQL-style query language, saved filters, bulk actions on results.', CYAN),
    ('Automation', 'No-code rules: when X happens, then assign / label / notify.', PINK),
    ('Goals & Workload', 'OKRs with key results, team capacity heat map.', GREEN),
    ('Notifications', 'Assignments, @mentions, status changes, sprint start - bell + inbox.', AMBER),
    ('Admin consoles', 'Super Admin (all orgs) and Org Admin (members, roles, audit log).', BLUE),
]
cw, ch = 176, 92; gx, gy = 34, H - 80 - ch
for i, (t, d, col) in enumerate(mods):
    x = gx + (i % 4) * (cw + 12); y = gy - (i // 4) * (ch + 14)
    box(x, y, cw, ch, fill=CARD, stroke=LINE)
    c.setFillColor(mix(col, 0.16)); c.roundRect(x + 10, y + ch - 32, 24, 24, 7, stroke=0, fill=1); c.setFillColor(col); c.setFont('Helvetica-Bold', 11); c.drawCentredString(x + 22, y + ch - 24.5, str(i + 1))
    c.setFillColor(INK); c.setFont('Helvetica-Bold', 10.5); c.drawString(x + 42, y + ch - 24, t)
    para(d, x + 12, y + ch - 40, cw - 22, style(8.6, MUTED, lead=11))
callout(34, 30, W - 68, 54, 'Design goals', 'Fast (pages in ~30 ms in production), secure (role checks on every API call, tenant isolation), futuristic UI (glass surfaces, spring animations, dark / light themes) and keyboard friendly: <b>Ctrl+K</b> command palette, <b>C</b> create issue, <b>G then D/P/S/N</b> navigate.', VIOLET)
c.showPage()

# ============================ 3. ARCHITECTURE ============================
header('2.  System architecture', 'A single Next.js monolith - UI, API, auth and jobs in one app, backed by MongoDB Atlas', 2)
# lanes
lanes = [('BROWSER', 34, CYAN), ('NEXT.JS SERVER (one process)', 250, VIOLET), ('DATA', 640, GREEN)]
node(34, H - 220, 170, 120, 'React UI (client)', 'Pages, drag & drop (dnd-kit), animations (Framer Motion), charts (Recharts). Caches API data per URL.', CYAN)
node(34, H - 360, 170, 100, 'Session cookie', 'httpOnly JWT <b>orbit_session</b> (7 days). Never readable by JavaScript.', CYAN)
node(250, H - 150, 160, 70, 'Middleware', 'Verifies the JWT, redirects guests to /login, blocks cross-origin writes (CSRF).', VIOLET)
node(250, H - 250, 160, 80, 'Server pages', 'App layout loads the user (cached 10 s) and renders the shell.', VIOLET)
node(430, H - 150, 190, 70, 'API route wrapper', 'route(): connect DB, authenticate, run handler, normalise errors into {ok, data|error}.', VIOLET)
node(430, H - 250, 190, 80, 'Domain services', 'createIssue, applyIssueUpdate (transition rules), sprint logic, automation engine, notifications.', VIOLET)
node(250, H - 360, 160, 90, 'RBAC policy', 'can(user, permission, project): platform > org > project role > ownership.', AMBER)
node(430, H - 360, 190, 90, 'OQL engine', 'Tokenizer, parser, compiler to a whitelisted Mongo filter - no raw user objects.', PINK)
node(660, H - 190, 150, 110, 'MongoDB Atlas', 'Database <b>team-sprint</b>. 14 collections, compound indexes, pooled connections.', GREEN)
node(660, H - 330, 150, 120, 'Collections', 'users, orgs, projects, issues, comments, worklogs, sprints, activity, notifications, audit, goals, filters, automations, teams', GREEN)
arrow(204, H - 160, 250, H - 120, CYAN, label='request + cookie')
arrow(204, H - 305, 250, H - 215, CYAN)
arrow(410, H - 115, 430, H - 115, VIOLET)
arrow(525, H - 150, 525, H - 170, VIOLET); arrow(525, H - 250, 525, H - 270, PINK)
arrow(410, H - 205, 430, H - 205, VIOLET)
arrow(410, H - 315, 430, H - 205, AMBER, dash=True)
arrow(620, H - 215, 660, H - 140, GREEN, label='Mongoose', lx=8)
callout(34, 120, 380, 92, 'Why a monolith?', 'One deployable app. No network hops between services, so each request is just: <b>cookie -> permission check -> 1-5 database queries -> JSON</b>. Easier to run (<font face="Courier">npm run serve</font>) and to reason about.', VIOLET)
callout(430, 120, 380, 92, 'Speed measures built in', '10-second user cache - lean queries without big text fields - compound indexes on issues (project+rank, assignee+status, sprint) - parallel queries - skeleton screens - production build.', GREEN)
c.showPage()

# ============================ 4. ROLES ============================
header('3.  Roles & permissions', 'Who can see and do what - enforced on the server for every request, then reflected in the UI', 3)
levels = [('Platform', 'Super Admin', 'All organizations, create orgs, suspend users, impersonate (audited)', RED),
          ('Organization', 'Org Admin', 'Members, roles, all projects, audit log, security', AMBER),
          ('Organization', 'Member / Guest', 'Member sees org-visible projects; Guest sees only invited ones', BLUE),
          ('Project', 'Project Admin', 'Settings, members, WIP limits, automation, sprints', VIOLET),
          ('Project', 'Developer', 'Create / edit / transition issues, sprints, work logs', CYAN),
          ('Project', 'Reporter', 'Create issues; edit and move only their own', GREEN),
          ('Project', 'Viewer', 'Read-only: no create, no drag; API gives 403', SLATE)]
y = H - 92
for i, (lv, name, d, col) in enumerate(levels):
    ind = i * 16
    box(34 + ind, y - 38, 400 - ind, 38, fill=mix(col, 0.10), stroke=col, r=9, shadow=False)
    chip(42 + ind, y - 20, lv, col, fs=7); c.setFillColor(INK); c.setFont('Helvetica-Bold', 10.5); c.drawString(120 + ind, y - 17, name)
    para(d, 120 + ind, y - 22, 306 - ind, style(8, MUTED, lead=9.5))
    y -= 46
# matrix
mx, my = 470, H - 92
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(mx, my + 2, 'Permission matrix (project level)')
cols = ['Admin', 'Dev', 'Reporter', 'Viewer']; acts = [('View project', [1, 1, 1, 1]), ('Create issue', [1, 1, 1, 0]), ('Edit any issue', [1, 1, 0, 0]), ('Edit own issue', [1, 1, 1, 0]), ('Move on board', [1, 1, 2, 0]), ('Assign issue', [1, 1, 0, 0]), ('Start / complete sprint', [1, 1, 0, 0]), ('Delete issue', [1, 0, 0, 0]), ('Manage members', [1, 0, 0, 0]), ('Automation rules', [1, 0, 0, 0])]
cx0 = mx + 150; rowh = 21; ytab = my - 18
for j, nm in enumerate(cols):
    c.setFillColor(MUTED); c.setFont('Helvetica-Bold', 8); c.drawCentredString(cx0 + j * 52 + 22, ytab, nm)
for i, (nm, vals) in enumerate(acts):
    yy = ytab - 8 - (i + 1) * rowh + 6
    c.setFillColor(CARD if i % 2 == 0 else mix(VIOLET, 0.05)); c.rect(mx - 6, yy - 6, 360, rowh, stroke=0, fill=1)
    c.setFillColor(INK); c.setFont('Helvetica', 9); c.drawString(mx, yy, nm)
    for j, v in enumerate(vals):
        cxm = cx0 + j * 52 + 22
        if v == 1: c.setFillColor(GREEN); c.circle(cxm, yy + 3, 5.5, stroke=0, fill=1); c.setStrokeColor(white); c.setLineWidth(1.5); c.line(cxm - 2.5, yy + 3, cxm - 0.7, yy + 1); c.line(cxm - 0.7, yy + 1, cxm + 3, yy + 5.5)
        elif v == 2: c.setFillColor(AMBER); c.circle(cxm, yy + 3, 5.5, stroke=0, fill=1); c.setFillColor(white); c.setFont('Helvetica-Bold', 6.5); c.drawCentredString(cxm, yy + 0.8, 'own')
        else: c.setFillColor(HexColor('#c9cde4')); c.circle(cxm, yy + 3, 3, stroke=0, fill=1)
callout(34, 30, W - 68, 62, 'Example - the same click, three outcomes', 'Lena (QA, <b>Developer</b>) drags ACME-50 to <i>In Review</i> - allowed. Tom (<b>Reporter</b>) drags an issue he did <u>not</u> create - the card springs back and a toast says "You do not have permission". Vera (<b>Viewer</b>) cannot even pick up the card, and calling the API directly returns <font face="Courier">403 FORBIDDEN</font>.', AMBER)
c.showPage()

# ============================ 5. AUTH FLOW ============================
header('4.  Sign-in & session flow', 'From the login form to a protected page - including lockout, stale sessions and impersonation', 4)
nodes = [('1  Open /login', 'Middleware sees no valid cookie and lets the public page render.', CYAN), ('2  Submit credentials', 'POST /api/auth/login with email + password (rate limited).', VIOLET), ('3  Verify', 'bcrypt compare. 5 wrong tries lock the account for 15 min.', AMBER), ('4  Issue session', 'Signed JWT in an httpOnly cookie; audit entry "auth.login".', GREEN), ('5  Enter the app', 'Shell loads, redirect to Dashboard (Super Admin goes to Platform).', PINK)]
x = 34
for i, (t, d, col) in enumerate(nodes):
    node(x, H - 190, 148, 96, t, d, col)
    if i < 4: arrow(x + 148, H - 142, x + 160, H - 142, SLATE, lw=2)
    x += 160
# failure branches
node(34 + 160 * 2, H - 300, 148, 80, 'Wrong password', 'Generic message "Incorrect email or password" - never reveals if the email exists.', RED)
arrow(34 + 160 * 2 + 74, H - 190, 34 + 160 * 2 + 74, H - 220, RED, dash=True)
node(34 + 160 * 3, H - 300, 148, 80, 'Suspended account', 'Login refused. Suspending a user also bumps tokenVersion, killing live sessions.', RED)
arrow(34 + 160 * 3 + 74, H - 190, 34 + 160 * 3 + 74, H - 220, RED, dash=True)
mono(34, H - 332, 380, ['# what the cookie carries (JWT payload)', '{ "uid": "6b04...e1ab", "tv": 0, "exp": +7d }', '', '# every request', 'cookie -> verify signature -> load user (10 s cache)', '       -> check status + tokenVersion -> allow / 401'])
callout(430, H - 436, 380, 104, 'Stale-session loop - fixed', 'If a cookie is valid but the user no longer exists (database reseeded, user deleted), the app used to bounce <i>/login -> /dashboard -> /login</i> forever (Chrome: "This page isn\'t working"). Now the layout redirects to <font face="Courier">/login?expired=1</font>, which <b>clears the cookie</b> and shows the form.', RED)
callout(34, 34, 380, 74, 'Impersonation (Super Admin only)', 'Platform console -> Users -> Manage -> Impersonate. A reason is required; the session lasts 2 h, an orange banner stays on screen, and every action is stored in the audit log with <i>impersonatedBy</i>.', AMBER)
callout(430, 34, 380, 74, 'Password change', 'Settings -> Change password increments <b>tokenVersion</b>. Every other device is signed out; the current browser receives a fresh cookie.', VIOLET)
c.showPage()

# ============================ 6. PROJECT CREATION ============================
header('5.  Creating a project', 'The 3-step wizard, and what the system builds behind the scenes', 5)
steps = [('Step 1 - Template', 'Pick Scrum, Kanban, Business or Service desk. Each shows its workflow.', VIOLET), ('Step 2 - Details', 'Name, key (auto-suggested), visibility, colour. Key must be unique and 2-10 letters.', CYAN), ('Step 3 - Team', 'Choose teammates. You become Project Admin; others become Developers (guests -> Reporters).', GREEN)]
x = 34
for i, (t, d, col) in enumerate(steps):
    node(x, H - 170, 190, 92, t, d, col)
    if i < 2: arrow(x + 190, H - 124, x + 214, H - 124, SLATE, lw=2)
    x += 214
node(34 + 214 * 3 - 10, H - 170, 175, 92, 'Created!', 'POST /api/projects, then open the board.', PINK)
arrow(34 + 214 * 2 + 190, H - 124, 34 + 214 * 3 - 10, H - 124, SLATE, lw=2)
# workflows
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(34, H - 200, 'Workflow created for each template')
wfs = [('Scrum', ['To Do', 'In Progress', 'In Review', 'QA', 'Done'], [SLATE, VIOLET, CYAN, AMBER, GREEN]), ('Kanban', ['To Do', 'In Progress', 'Done'], [SLATE, VIOLET, GREEN]), ('Business', ['Backlog', 'Doing', 'Review', 'Done'], [SLATE, VIOLET, CYAN, GREEN]), ('Service desk', ['Waiting for support', 'In progress', 'Waiting for customer', 'Resolved'], [SLATE, VIOLET, AMBER, GREEN])]
y = H - 232
for nm, sts, cols_ in wfs:
    c.setFillColor(MUTED); c.setFont('Helvetica-Bold', 9); c.drawString(34, y + 4, nm)
    x = 120
    for s_, col in zip(sts, cols_):
        w = max(58, c.stringWidth(s_, 'Helvetica-Bold', 8) + 22)
        c.setFillColor(mix(col, 0.15)); c.setStrokeColor(col); c.setLineWidth(0.8); c.roundRect(x, y - 2, w, 20, 10, stroke=1, fill=1)
        c.setFillColor(col); c.circle(x + 9, y + 8, 2.6, stroke=0, fill=1); c.setFillColor(INK); c.setFont('Helvetica-Bold', 8); c.drawString(x + 15, y + 5, s_)
        x += w + 4
        if s_ != sts[-1]: arrow(x - 3, y + 8, x + 6, y + 8, SLATE, lw=1); x += 8
    y -= 30
mono(34, H - 365, 380, ['# example request body', 'POST /api/projects', '{ "name": "Mobile Apps", "key": "MOB",', '  "type": "kanban", "visibility": "org",', '  "memberIds": ["<Diego>", "<Mei>"] }', '', '# server creates', 'project + workflow + members + (Scrum: "MOB Sprint 1")', '# and writes audit: project.created'])
callout(430, H - 470, 380, 105, 'Validation you will actually see', '- Key <b>ACME</b> already used -> field error "Key already in use" (409).<br/>- Key "acme1x!" -> "Use 2-10 uppercase letters/numbers, starting with a letter".<br/>- Free-plan org over its project limit -> "Project limit reached for your plan" (402).', RED)
callout(34, 34, W - 68, 60, 'Result', 'Project <b>MOB</b> exists with the Kanban workflow. Issue keys will be <b>MOB-1, MOB-2, ...</b> generated atomically from the project counter, so two people creating issues at the same instant never get the same number.', GREEN)
c.showPage()

# ============================ 7. ISSUE LIFECYCLE ============================
header('6.  Issue lifecycle', 'Follow one real issue - ACME-50 "Dark theme for charts and data tables" - from idea to done', 6)
stages = [('Created', 'Tom (Reporter) presses C, types the summary, picks type Story.', SLATE, 'Status: To Do - in Backlog'), ('Ranked', 'Marcus (PO) orders it in the backlog and sets 5 points.', CYAN, 'Rank between neighbours'), ('Planned', 'Priya drags it into "ACME Sprint 6".', VIOLET, 'sprintId set'), ('In progress', 'Sara assigns herself and drags the card across the board.', PINK, 'Notification to watchers'), ('In review', 'Lena is @mentioned in a comment.', AMBER, 'Bell + inbox for Lena'), ('Done', 'Lena moves it to Done; resolvedAt is stamped.', GREEN, 'Burndown drops by 5')]
x = 34
for i, (t, d, col, res) in enumerate(stages):
    node(x, H - 214, 124, 120, t, d, col)
    c.setFillColor(col); c.setFont('Helvetica-Oblique', 7.5); para(res, x + 4, H - 222, 118, style(7.6, col, bold=True, align=TA_CENTER, lead=9))
    if i < 5: arrow(x + 124, H - 154, x + 133, H - 154, SLATE, lw=2)
    x += 133
# issue card mock
box(34, H - 430, 330, 170, fill=CARD, stroke=VIOLET, r=12, lw=1.4)
c.setFillColor(mix(GREEN, 0.2)); c.roundRect(46, H - 292, 18, 18, 5, stroke=0, fill=1); c.setFillColor(GREEN); c.setFont('Helvetica-Bold', 9); c.drawCentredString(55, H - 286, 'S')
c.setFillColor(MUTED); c.setFont('Courier-Bold', 9); c.drawString(72, H - 286, 'ACME-50'); chip(300, H - 291, 'IN REVIEW', CYAN, fs=7)
c.setFillColor(INK); c.setFont('Helvetica-Bold', 12); c.drawString(46, H - 315, 'Dark theme for charts and data tables')
fields = [('Assignee', 'Sara Dev'), ('Priority', 'Medium'), ('Story points', '5'), ('Sprint', 'ACME Sprint 6'), ('Epic', 'Dark Mode & Design System'), ('Labels', 'design')]
for i, (k, v) in enumerate(fields):
    cx_ = 46 + (i % 2) * 160; cy_ = H - 338 - (i // 2) * 24
    c.setFillColor(MUTED); c.setFont('Helvetica', 7.5); c.drawString(cx_, cy_ + 8, k.upper()); c.setFillColor(INK); c.setFont('Helvetica-Bold', 9); c.drawString(cx_, cy_ - 2, v)
mono(380, H - 262, 430, ['# the history tab records every change', 'Marcus     created this issue', 'Priya      sprintId   (none) -> ACME Sprint 6', 'Sara       assignee   (none) -> Sara Dev', 'Sara       status     To Do -> In Progress', 'Lena       commented: "@Sara Dev tests pass"', 'Lena       status     In Review -> Done', '# resolvedAt stamped, resolution = "Done"'])
callout(380, H - 478, 430, 100, 'Business rules enforced by the server', '- Only users who can create issues in the project can be assigned.<br/>- Moving to a Done status sets <i>resolvedAt</i> - this powers burndown and cycle-time reports.<br/>- Concurrent edits: sending an old <i>version</i> returns 409 "Someone else updated this issue".<br/>- Sub-tasks cannot become epics; epics cannot be children.', AMBER)
callout(34, 34, W - 68, 58, 'Where you do each step', 'Create: <b>C</b> or the Create button  -  Open: click a card (side drawer) or visit /issues/ACME-50  -  Edit: click any field (saves instantly, with undo-friendly toast)  -  Work log: type <font face="Courier">2h 30m</font>  -  Mention: type <font face="Courier">@Sara</font> in a comment.', CYAN)
c.showPage()

# ============================ 8. BOARD DND ============================
header('7.  Board & drag-and-drop', 'What happens in the 200 milliseconds between letting go of a card and seeing it settle', 7)
# board mock
cols_ = [('TO DO', SLATE, ['Update docs', 'Rate limit API']), ('IN PROGRESS', VIOLET, ['Dark theme charts']), ('IN REVIEW', CYAN, []), ('DONE', GREEN, ['Password meter'])]
x = 34
for nm, col, cards in cols_:
    box(x, H - 330, 140, 238, fill=mix(col, 0.07), stroke=LINE, r=12, shadow=False)
    c.setFillColor(col); c.circle(x + 14, H - 112, 4, stroke=0, fill=1); c.setFillColor(INK); c.setFont('Helvetica-Bold', 8.5); c.drawString(x + 24, H - 115, nm)
    for k, t in enumerate(cards):
        yy = H - 160 - k * 52
        box(x + 10, yy - 20, 120, 44, fill=CARD, stroke=LINE, r=8, shadow=True)
        c.setFillColor(INK); c.setFont('Helvetica-Bold', 8.4); c.drawString(x + 18, yy + 10, t); c.setFillColor(MUTED); c.setFont('Courier', 7.2); c.drawString(x + 18, yy - 8, 'ACME-' + str(40 + k + len(nm)))
    x += 150
# dragging card
c.saveState(); c.translate(346, H - 196); c.rotate(-4)
box(0, 0, 122, 46, fill=CARD, stroke=VIOLET, r=8, lw=1.8); c.setFillColor(INK); c.setFont('Helvetica-Bold', 8.4); c.drawString(8, 30, 'Dark theme charts'); c.setFillColor(MUTED); c.setFont('Courier', 7.2); c.drawString(8, 14, 'ACME-50'); c.restoreState()
arrow(318, H - 138, 344, H - 138, VIOLET, lw=2.4)
c.setFillColor(VIOLET); c.setFont('Helvetica-Bold', 8); c.drawString(322, H - 128, 'drag')
# sequence
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(660, H - 100, 'What happens')
seq = [('Optimistic move', 'Card is placed instantly in the UI.'), ('POST /api/issues/rank', '{ key, status:"review", aboveKey, belowKey }'), ('Permission check', 'issue.transition (own-only for Reporters).'), ('Compute rank', 'Midpoint between neighbours, e.g. (4000+5000)/2.'), ('Save + side effects', 'History entry, notifications, automation rules.'), ('Success / rollback', 'Done: green pulse + toast. Error: card shakes and returns.')]
y = H - 120
for i, (t, d) in enumerate(seq):
    step(i + 1, 672, y - 8, [VIOLET, CYAN, AMBER, PINK, GREEN, RED][i]); c.setFillColor(INK); c.setFont('Helvetica-Bold', 8.8); c.drawString(688, y - 5, t); para(d, 688, y - 9, 140, style(7.8, MUTED, lead=9.4)); y -= 37
mono(34, H - 352, 380, ['# example: the drop that is rejected', 'Tom (Reporter) drags ACME-66 (not his)', '-> 403 FORBIDDEN', '-> UI: card shakes, rolls back, toast shown'])
callout(430, H - 438, 218, 86, 'WIP limits', 'MOB project: In Progress limit 4. At 5 cards the column glows red with a "WIP exceeded" tag - a visual nudge to finish work first.', RED)
callout(34, 34, 614, 62, 'Board extras', '<b>Swimlanes by assignee</b> (one board per person), <b>Only my issues</b> filter, <b>flagged</b> cards with striped background, <b>aging badge</b> (e.g. "9d") on in-progress cards that have not moved for a week, keyboard drag with arrow keys.', CYAN)
c.showPage()

# ============================ 9. SPRINT LIFECYCLE ============================
header('8.  Sprint lifecycle', 'Backlog -> planning -> active sprint -> completion, with the numbers behind each step', 8)
st = [('Future', 'Create sprint "ACME Sprint 6". Drag issues in from the backlog; capacity shows 32 / 35 pts (avg velocity).', SLATE), ('Start', 'Pick duration (2 weeks), set a goal. Needs at least one issue; only one active sprint at a time.', VIOLET), ('Active', 'Daily board work. Burndown plots remaining points against the ideal line.', GREEN), ('Complete', 'Choose where open issues go: Backlog or the next sprint. Velocity is recorded.', PINK)]
x = 34
for i, (t, d, col) in enumerate(st):
    node(x, H - 190, 176, 100, t, d, col)
    if i < 3: arrow(x + 176, H - 140, x + 194, H - 140, SLATE, lw=2)
    x += 194
# burndown chart mock
c.saveState(); c.translate(0, 34)
cx0, cy0, cw_, ch_ = 56, 80, 360, 190
box(34, 56, 404, 232, fill=CARD, stroke=LINE, r=12)
c.setFillColor(INK); c.setFont('Helvetica-Bold', 10); c.drawString(48, 270, 'Burndown - ACME Sprint 5 (35 pts, day 6 of 14)')
c.setStrokeColor(LINE); c.setLineWidth(0.5)
for k in range(5): c.line(cx0, cy0 + k * 38, cx0 + cw_, cy0 + k * 38)
c.setStrokeColor(SLATE); c.setDash(4, 3); c.setLineWidth(1.4); c.line(cx0, cy0 + 152, cx0 + cw_, cy0); c.setDash()
pts = [(0, 152), (60, 150), (90, 140), (130, 118), (170, 100), (210, 92), (250, 80)]
c.setStrokeColor(VIOLET); c.setLineWidth(2.6)
for (xa, ya), (xb, yb) in zip(pts, pts[1:]): c.line(cx0 + xa, cy0 + ya, cx0 + xb, cy0 + yb)
for xa, ya in pts: c.setFillColor(VIOLET); c.circle(cx0 + xa, cy0 + ya, 3, stroke=0, fill=1)
c.setFillColor(MUTED); c.setFont('Helvetica', 7.5); c.drawString(cx0 + 262, cy0 + 118, 'ideal'); c.setFillColor(VIOLET); c.drawString(cx0 + 262, cy0 + 84, 'actual: 15 pts left'); c.setFillColor(MUTED); c.drawString(cx0, cy0 - 12, 'Day 0'); c.drawRightString(cx0 + cw_, cy0 - 12, 'Day 14')
# velocity bars
box(454, 56, 356, 232, fill=CARD, stroke=LINE, r=12)
c.setFillColor(INK); c.setFont('Helvetica-Bold', 10); c.drawString(468, 270, 'Velocity - committed vs completed')
vel = [('S1', 32, 29), ('S2', 35, 32), ('S3', 37, 34), ('S4', 39, 36), ('S5', 35, 20)]
for i, (n, cm, cp) in enumerate(vel):
    bx = 478 + i * 64
    c.setFillColor(HexColor('#c9cde4')); c.rect(bx, 84, 20, cm * 4.2, stroke=0, fill=1); c.setFillColor(CYAN if i < 4 else AMBER); c.rect(bx + 22, 84, 20, cp * 4.2, stroke=0, fill=1)
    c.setFillColor(MUTED); c.setFont('Helvetica-Bold', 8); c.drawCentredString(bx + 21, 70, n); c.setFont('Helvetica', 7); c.drawCentredString(bx + 32, 86 + cp * 4.2, str(cp))
chip(468, 250, 'committed', SLATE, fs=7); chip(530, 250, 'completed', CYAN, fs=7)
c.restoreState()
callout(34, 24, W - 68, 46, 'Reading the numbers', 'Sprint 5 committed <b>35 pts</b>; on day 6, <b>20 pts</b> are done (57%) and <b>15 pts</b> remain, slightly ahead of the ideal line. Average velocity of Sprints 1-4 is <b>33 pts</b>, which the planning assistant uses to suggest how many issues fit Sprint 6.', VIOLET)
c.setFillColor(INK)
c.showPage()

# ============================ 10. OQL ============================
header('9.  Search with OQL', "Orbit Query Language - a JQL-style language compiled safely to MongoDB filters", 9)
node(34, H - 175, 140, 80, 'You type', 'status IN ("QA","Done") AND priority >= High ORDER BY updated DESC', PINK)
node(196, H - 175, 140, 80, 'Tokenizer', 'Splits into words, strings, operators and brackets.', VIOLET)
node(358, H - 175, 140, 80, 'Parser', 'Builds an AST: AND / OR / NOT with comparisons.', CYAN)
node(520, H - 175, 140, 80, 'Compiler', 'Whitelist of fields; resolves users, projects, sprints; builds the filter.', AMBER)
node(682, H - 175, 128, 80, 'Result', 'Visible projects only; lean query using indexes.', GREEN)
for xx in (174, 336, 498, 660): arrow(xx, H - 135, xx + 22, H - 135, SLATE, lw=2)
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(34, H - 205, 'Ready-made examples (try them on the Filters page)')
ex = [('My open bugs', 'type = bug AND assignee = currentUser() AND statusCategory != done'), ('Overdue and important', 'priority >= High AND due < now() AND statusCategory != done ORDER BY due ASC'), ('Active sprint', 'project = ACME AND sprint IN openSprints() ORDER BY rank ASC'), ('Resolved this week', 'resolved >= -7d ORDER BY resolved DESC'), ('Unassigned work', 'assignee IS EMPTY AND statusCategory != done'), ('Text search', 'text ~ "payment" OR text ~ "stripe"')]
y = H - 222
for i, (t, q) in enumerate(ex):
    xx = 34 + (i % 2) * 390; yy = y - (i // 2) * 62
    box(xx, yy - 48, 382, 52, fill=CARD, stroke=LINE, r=9); c.setFillColor(PINK if i % 2 else VIOLET); c.setFont('Helvetica-Bold', 9); c.drawString(xx + 10, yy - 14, t)
    para(q, xx + 10, yy - 19, 362, style(7.6, INK, lead=9.4).clone('m', fontName='Courier'))
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(34, 178, 'Reference')
ref = [('Fields', 'project status assignee reporter priority type labels sprint created updated due resolved text key points'), ('Operators', '=  !=  >  >=  <  <=  ~ (contains)  IN  NOT IN  IS EMPTY  IS NOT EMPTY'), ('Logic', 'AND  OR  NOT  ( ... )'), ('Functions', 'currentUser()  now()  startOfWeek()  openSprints()   - dates like -7d, -2w'), ('Safe by design', 'Unknown field -> error. A value like {"$ne":1} is rejected at the tokenizer, so NoSQL injection is not possible.')]
yy = 160
for k, v in ref:
    chip(34, yy - 4, k, VIOLET, w=84, fs=7.6); para(v, 128, yy + 6, 680, style(8.4, INK, lead=10)); yy -= 19
callout(34, 30, W - 68, 38, 'After searching', 'Select rows to bulk-change status, assignee or priority (a floating bar appears), click a row to open the issue drawer, or press <b>Save</b> to keep the query as a shared filter.', GREEN)
c.showPage()

# ============================ 11. AUTOMATION + NOTIFICATIONS ============================
header('10.  Automation & notifications', 'Rules react to events; notifications keep the right people informed', 10)
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(34, H - 86, 'Automation rule - "Highest-priority bugs notify the lead"')
node(34, H - 190, 170, 80, 'WHEN', 'An issue is created in ACME.', VIOLET)
node(244, H - 190, 170, 80, 'IF', 'priority = Highest.', AMBER)
node(454, H - 190, 170, 80, 'THEN', 'Notify project lead (Priya).', GREEN)
node(664, H - 190, 146, 80, 'LOG', 'runCount + lastRunAt; history shows "ran automation".', PINK)
for xx in (204, 414, 624): arrow(xx, H - 150, xx + 40, H - 150, SLATE, lw=2.2)
c.setFillColor(MUTED); c.setFont('Helvetica', 8.3); c.drawString(34, H - 208, 'Triggers: issue created, status changed.   Conditions: priority / status / type.   Actions: assign to lead, set priority, add label, notify lead.   Toggle on or off any time.')
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(34, H - 240, 'Notification fan-out when Sara comments "@Lena Fischer can you test this?" on ACME-50')
node(34, H - 360, 150, 90, 'Comment saved', 'POST /api/issues/ACME-50/comments, mentions parsed from the text.', VIOLET)
node(262, H - 330, 170, 60, 'Mentioned', 'Lena: "Sara mentioned you on ACME-50".', PINK)
node(262, H - 400, 170, 60, 'Watchers', 'Assignee, reporter, watchers: "Sara commented on ACME-50".', CYAN)
node(520, H - 330, 140, 60, 'Bell badge', 'Number appears, refreshed every 45 s.', AMBER)
node(520, H - 400, 140, 60, 'Inbox page', 'Unread / All / Mentions tabs, mark all read.', GREEN)
arrow(184, H - 300, 262, H - 300, SLATE); arrow(184, H - 330, 262, H - 370, SLATE)
arrow(432, H - 300, 520, H - 300, SLATE); arrow(432, H - 370, 520, H - 370, SLATE)
callout(690, H - 400, 120, 130, 'Rules', 'You never notify yourself. Duplicates are merged. Clicking a notification marks it read and opens the issue.', VIOLET)
callout(34, 34, W - 68, 58, 'Other notification triggers', 'Assigned to you  -  status changed on something you watch  -  sprint started  -  added to a project  -  automation fired. Each notification stores who did it, a message and the issue key.', CYAN)
c.showPage()

# ============================ 12. ADMIN ============================
header('11.  Administration', 'Two consoles: Platform (Super Admin) and Organization (Org Admin)', 11)
box(34, 56, 380, H - 130, fill=CARD, stroke=RED, r=14, lw=1.4)
c.setFillColor(RED); c.setFont('Helvetica-Bold', 12); c.drawString(50, H - 92, 'Super Admin - /admin/platform')
for i, (t, d) in enumerate([('Overview', 'Totals for orgs, users, projects, issues; 14-day login and issue chart; system health (database, uptime, memory); newest users.'), ('Organizations', 'Create an org: name, plan (free / pro / enterprise) and its first admin - a one-time temporary password is shown once. Suspend or change plan limits.'), ('Users', 'Search everyone. Suspend, unlock, sign out everywhere, reset password, make / remove Super Admin (the last one is protected), impersonate.'), ('Audit log', 'Every important action across all orgs, filterable, with "via" marker for impersonation.')]):
    yy = H - 118 - i * 92
    step(i + 1, 56, yy - 4, RED); c.setFillColor(INK); c.setFont('Helvetica-Bold', 10); c.drawString(72, yy - 7, t); para(d, 72, yy - 12, 330, style(8.5, MUTED, lead=10.6))
box(430, 56, 380, H - 130, fill=CARD, stroke=AMBER, r=14, lw=1.4)
c.setFillColor(AMBER); c.setFont('Helvetica-Bold', 12); c.drawString(446, H - 92, 'Org Admin - /admin/org')
for i, (t, d) in enumerate([('Members', 'Table with role dropdown (Org Admin / Member / Guest), project chips, last active, status. Deactivating someone unassigns their open issues.'), ('Invite', 'Name, email, role, title. The account is created with a temporary password shown once - no email server needed.'), ('Safeguards', 'You cannot demote or deactivate yourself, and the org always keeps at least one active admin. Plan user limits are enforced.'), ('Audit log', 'Everything that happened inside your organization.')]):
    yy = H - 118 - i * 92
    step(i + 1, 452, yy - 4, AMBER); c.setFillColor(INK); c.setFont('Helvetica-Bold', 10); c.drawString(468, yy - 7, t); para(d, 468, yy - 12, 330, style(8.5, MUTED, lead=10.6))
mono(446, 168, 350, ['# example: create organization "Initech"', 'POST /api/admin/platform/orgs', '{ name:"Initech", plan:"pro",', '  adminName:"Bill", adminEmail:"bill@initech.io" }', '-> { temporaryPassword: "Welcome-x7k2m91A" }'])
c.showPage()

# ============================ 13. DATA MODEL ============================
header('12.  Data model', 'How the main collections in MongoDB relate - all business data carries orgId for tenant isolation', 12)
def ent(x, y, w, name, fields, col):
    h = 22 + len(fields) * 11.5 + 6
    box(x, y - h, w, h, fill=CARD, stroke=col, r=8, lw=1.3); c.setFillColor(col); c.roundRect(x, y - 20, w, 20, 8, stroke=0, fill=1); c.rect(x, y - 20, w, 8, stroke=0, fill=1)
    c.setFillColor(white); c.setFont('Helvetica-Bold', 9); c.drawString(x + 8, y - 14, name)
    for i, f in enumerate(fields): c.setFillColor(INK if not f.startswith('*') else col); c.setFont('Courier-Bold' if f.startswith('*') else 'Courier', 7.2); c.drawString(x + 8, y - 32 - i * 11.5, f)
    return (x, y, w, h)
org = ent(34, H - 80, 140, 'orgs', ['*_id', 'name, slug', 'plan, limits'], GREEN)
usr = ent(34, H - 190, 140, 'users', ['*_id', 'orgId', 'name, email', 'role, platformRole', 'status, tokenVersion'], CYAN)
prj = ent(240, H - 80, 160, 'projects', ['*_id', 'orgId, key, type', 'leadId', 'members[userId,role]', 'statuses[], wip{}', 'issueCounter'], VIOLET)
spr = ent(450, H - 80, 150, 'sprints', ['*_id', 'projectId', 'state, goal', 'startDate, endDate', 'committed, completed'], AMBER)
iss = ent(240, H - 230, 200, 'issues', ['*_id', 'projectId, key (ACME-50)', 'type, summary, description', 'status, statusCategory', 'priority, points, rank', 'assigneeId, reporterId', 'sprintId, epicId, parentId', 'timeSpent, dueDate, version'], PINK)
com = ent(480, H - 250, 150, 'comments', ['*_id', 'issueId, authorId', 'body, mentions[]'], BLUE)
wl = ent(480, H - 320, 150, 'worklogs', ['*_id', 'issueId, userId', 'seconds, startedAt'], BLUE)
act = ent(660, H - 80, 150, 'activity', ['*_id', 'issueId, actorId', 'action, diff{}'], SLATE)
nt = ent(660, H - 170, 150, 'notifications', ['*_id', 'userId, actorId', 'message, issueKey', 'readAt'], SLATE)
au = ent(660, H - 260, 150, 'audit', ['*_id', 'actorId, action', 'impersonatedBy', 'target'], RED)
ot = ent(660, H - 350, 150, 'goals / filters / automations', ['org-level records'], GREEN)
for (x1, y1, x2, y2) in [(174, H - 100, 240, H - 100), (104, H - 190 + 0, 104, H - 104), (320, H - 160, 320, H - 230), (400, H - 105, 450, H - 105), (440, H - 290, 480, H - 275), (440, H - 300, 480, H - 330), (440, H - 260, 660, H - 120)]:
    arrow(x1, y1, x2, y2, SLATE, lw=1.2)
callout(34, 34, 380, 98, 'Indexes added for speed', 'issues: (projectId, deletedAt, rank), (projectId, sprintId), (assigneeId, statusCategory, dueDate), (orgId, key) unique.<br/>notifications: (userId, createdAt) and (userId, readAt).<br/>activity, comments, worklogs, audit, sprints: by parent id + time.', GREEN)
callout(430, 34, 380, 98, 'Tenant isolation example', 'Alex (Acme admin) opens GLX-1, a Globex issue, by typing the URL: the API filters by <b>orgId</b> first and answers <font face="Courier">404 Not found</font> - not 403 - so he cannot even tell it exists. Private project PLAT is invisible to Sara in the same way.', RED)
c.showPage()

# ============================ 14. TESTING + RUN ============================
header('13.  Run it & test it', 'Start commands, demo accounts and a 10-minute walkthrough that exercises every role', 13)
mono(34, H - 80, 330, ['# start (fast production mode)', 'cd Sprint_Project', 'npm install', 'npm run seed     # fills MongoDB Atlas', 'npm run serve    # build + start :7000', '', '# or during development', 'npm run dev      # slower first visit', 'npm test         # 12 unit tests'])
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(34, H - 230, 'Demo accounts')
rows = [('Super Admin', 'superadmin@orbit.dev', 'Orbit@Super123!', RED), ('Org Admin', 'admin@acme.dev', 'Orbit@Admin123!', AMBER), ('Scrum Master', 'priya.lead@acme.dev', 'Orbit@Demo123!', VIOLET), ('Developer', 'sara.dev@acme.dev', 'Orbit@Demo123!', CYAN), ('QA', 'lena.qa@acme.dev', 'Orbit@Demo123!', GREEN), ('Reporter', 'tom.reporter@acme.dev', 'Orbit@Demo123!', PINK), ('Viewer', 'vera.viewer@acme.dev', 'Orbit@Demo123!', SLATE), ('Guest', 'guest@client.com', 'Orbit@Demo123!', BLUE)]
for i, (r_, e, p, col) in enumerate(rows):
    yy = H - 252 - i * 22
    c.setFillColor(CARD if i % 2 == 0 else mix(VIOLET, 0.05)); c.rect(34, yy - 6, 330, 22, stroke=0, fill=1)
    chip(40, yy - 2, r_, col, w=76, fs=7); c.setFillColor(INK); c.setFont('Courier', 8); c.drawString(124, yy + 1, e); c.setFillColor(MUTED); c.drawString(266, yy + 1, p)
c.setFillColor(INK); c.setFont('Helvetica-Bold', 11); c.drawString(390, H - 86, '10-minute walkthrough')
walk = [('Sign in as Super Admin', 'See the Platform overview, create an org, impersonate a user, exit from the banner.', RED), ('Sign in as Org Admin', 'Invite a member, change a role, read the audit log.', AMBER), ('Sign in as Priya', 'Backlog: drag 2 issues into Sprint 6, start it. Check Reports.', VIOLET), ('Sign in as Sara', 'Board: drag a card, edit a field inline, log "1h 30m", comment with @Lena.', CYAN), ('Sign in as Lena', 'Open the bell: the mention is there. Move the card to Done.', GREEN), ('Sign in as Vera (Viewer)', 'No Create button, cards will not drag, API writes return 403.', SLATE), ('Sign in as Guest', 'Only the Support project is visible; ACME URLs give 404.', BLUE)]
for i, (t, d, col) in enumerate(walk):
    yy = H - 112 - i * 46
    step(i + 1, 404, yy - 6, col); c.setFillColor(INK); c.setFont('Helvetica-Bold', 9.4); c.drawString(420, yy - 9, t); para(d, 420, yy - 13, 380, style(8.4, MUTED, lead=10.2))
callout(34, 34, W - 68, 58, 'If the site shows "This page isn\'t working"', 'Hard-refresh (Ctrl+Shift+R). A stale session cookie now clears itself via <font face="Courier">/login?expired=1</font>. If the server is not running, start it again with <font face="Courier">npm run serve</font> in the Sprint_Project folder.', RED)
c.showPage()
c.save()
print('saved', OUT, 'pages', page_no[0])
