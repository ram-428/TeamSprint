const SEARCH_THRESHOLD = 7;
/** Custom listbox (Siva Durga style): 40px trigger, portal panel that flips upward, search once the list is long, keyboard friendly. */
export function Select({ value, onChange, options, className, disabled, placeholder = 'Select…', ...rest }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[]; className?: string; disabled?: boolean; placeholder?: string } & Omit<React.HTMLAttributes<HTMLElement>, 'onChange'>) {
  const [open, setOpen] = useState(false); const [q, setQ] = useState(''); const [idx, setIdx] = useState(0);
  const [pos, setPos] = useState<{ left: number; width: number; top?: number; bottom?: number; maxH: number } | null>(null);
  const trig = useRef<HTMLButtonElement>(null); const search = useRef<HTMLInputElement>(null);
  const selected = options.find((o) => o.value === value); const searchable = options.length > SEARCH_THRESHOLD;
  const list = searchable && q.trim() ? options.filter((o) => o.label.toLowerCase().includes(q.trim().toLowerCase())) : options;
  useEffect(() => {
    if (!open) return;
    const place = () => {
      const r = trig.current?.getBoundingClientRect(); if (!r) return;
      const below = window.innerHeight - r.bottom, above = r.top; const up = below < 260 && above > below;
      setPos({ left: r.left, width: Math.max(r.width, 160), maxH: Math.min(288, (up ? above : below) - 16), top: up ? undefined : r.bottom + 6, bottom: up ? window.innerHeight - r.top + 6 : undefined });
    };
    const onScroll = (e: Event) => { if (!(e.target as HTMLElement)?.closest?.('[data-listbox]')) place(); };
    const close = (e: Event) => { if (!(e.target as HTMLElement)?.closest?.('[data-listbox]') && !trig.current?.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') { setOpen(false); trig.current?.focus(); } };
    place(); setQ(''); setIdx(Math.max(0, options.findIndex((o) => o.value === value)));
    if (searchable) requestAnimationFrame(() => search.current?.focus());
    window.addEventListener('resize', place); window.addEventListener('scroll', onScroll, true);
    document.addEventListener('mousedown', close); document.addEventListener('keydown', esc);
    return () => { window.removeEventListener('resize', place); window.removeEventListener('scroll', onScroll, true); document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const pick = (v: string) => { onChange(v); setOpen(false); trig.current?.focus(); };
  const onKey = (e: React.KeyboardEvent) => {
    if (!open && ['ArrowDown', 'ArrowUp'].includes(e.key)) { e.preventDefault(); setOpen(true); return; }
    if (!open) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((i) => Math.min(list.length - 1, i + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)); }
    else if (e.key === 'Enter') { e.preventDefault(); if (list[idx]) pick(list[idx].value); }
  };
  useEffect(() => { document.querySelector(`[data-lb="${idx}"]`)?.scrollIntoView({ block: 'nearest' }); }, [idx]);
  return (
    <div className={clsx('relative', className || 'w-full')}>
      <button ref={trig} type="button" role="combobox" aria-haspopup="listbox" aria-expanded={open} aria-label={(rest as Record<string, string>)['aria-label']} disabled={disabled} onClick={() => setOpen((o) => !o)} onKeyDown={onKey}
        className={clsx('flex h-10 w-full items-center gap-2 rounded-lg border bg-[var(--surface)] px-3 text-left text-[14px] transition-all disabled:cursor-not-allowed disabled:opacity-50', open ? 'border-[var(--accent)] shadow-[0_0_0_3px_var(--accent-soft)]' : 'border-[var(--border)] hover:border-[var(--border-strong)]')}>
        <span className={clsx('min-w-0 flex-1 truncate', !selected && 'text-faint')}>{selected?.label ?? placeholder}</span>
        <ChevronDown size={15} className={clsx('shrink-0 text-faint transition-transform', open && 'rotate-180 text-accent')} />
      </button>
      {typeof document !== 'undefined' && createPortal(
        <AnimatePresence>
          {open && pos && (
            <motion.div data-listbox role="listbox" initial={{ opacity: 0, y: pos.bottom ? 6 : -6, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }} transition={{ duration: 0.14 }}
              style={{ position: 'fixed', left: pos.left, width: pos.width, top: pos.top, bottom: pos.bottom, zIndex: 200 }} className="glass-solid overflow-hidden rounded-xl">
              {searchable && <div className="border-b border-[var(--border)] p-2"><div className="relative"><SearchIcon size={14} className="absolute left-2.5 top-[9px] text-faint" /><input ref={search} aria-label="Search options" value={q} onChange={(e) => { setQ(e.target.value); setIdx(0); }} onKeyDown={onKey} placeholder="Search…" className="h-8 w-full rounded-lg border border-[var(--border)] bg-transparent pl-8 pr-2 text-[13px] outline-none focus:border-[var(--accent)]" /></div></div>}
              <div className="overflow-y-auto p-1" style={{ maxHeight: pos.maxH - (searchable ? 48 : 0) }}>
                {list.length === 0 && <div className="px-3 py-4 text-center text-[13px] text-faint">No matches</div>}
                {list.map((o, i) => (
                  <button key={o.value + i} type="button" role="option" aria-selected={o.value === value} data-lb={i} onMouseEnter={() => setIdx(i)} onClick={() => pick(o.value)}
                    className={clsx('flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[13.5px] transition-colors', i === idx && 'bg-[var(--accent-soft)]', o.value === value && 'font-semibold')}>
                    <span className="min-w-0 flex-1 truncate">{o.label}</span>{o.value === value && <Check size={14} className="shrink-0 text-accent" />}
                  </button>))}
              </div>
            </motion.div>)}
        </AnimatePresence>, document.body)}
    </div>
  );
}
