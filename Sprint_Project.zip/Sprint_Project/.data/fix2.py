p = 'scripts/seed.ts'
lines = open(p, encoding='utf8').read().split('\n')
# lines[3] and lines[4] are the broken two-line statement
new = "for (const f of ['.env.local', '.env']) if (fs.existsSync(f)) for (const l of fs.readFileSync(f, 'utf8').split(/\\r?\\n/)) { const m = /^([A-Z_]+)=(.*)$/.exec(l); if (m && !process.env[m[1]]) process.env[m[1]] = m[2]; }"
assert lines[3].startswith('for (const f of')
lines[3:5] = [new]
open(p, 'w', encoding='utf8').write('\n'.join(lines))
