1:"$Sreact.fragment"
2:I[9766,[],""]
3:I[98924,[],""]
4:I[52619,["2619","static/chunks/2619-04bc32f026a0d946.js","4345","static/chunks/app/not-found-28f52526afeacdc6.js"],""]
5:I[11068,["8336","static/chunks/8336-0fbfc65b5572d298.js","7177","static/chunks/app/layout-68ad83234308e66f.js"],"Toaster"]
7:I[24431,[],"OutletBoundary"]
9:I[15278,[],"AsyncMetadataOutlet"]
b:I[24431,[],"ViewportBoundary"]
d:I[24431,[],"MetadataBoundary"]
e:"$Sreact.suspense"
10:I[57150,[],""]
:HL["/_next/static/css/74a9d4b7e9692715.css","style"]
0:{"P":null,"b":"R9KS8pfnhCm65zqF8Kyiz","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/74a9d4b7e9692715.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","data-theme":"dark","className":"__variable_d8ebd1 __variable_4dc837","suppressHydrationWarning":true,"children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"try{var t=localStorage.getItem('orbit-theme')||'dark';document.documentElement.setAttribute('data-theme',t)}catch(e){document.documentElement.setAttribute('data-theme','dark')}"}}]}],["$","body",null,{"children":[["$","div",null,{"className":"aurora","aria-hidden":true,"children":[["$","i",null,{}],["$","i",null,{}],["$","i",null,{}]]}],["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"flex min-h-screen flex-col items-center justify-center p-6 text-center","children":[["$","div",null,{"className":"float grad-text text-[120px] font-bold leading-none","children":"404"}],["$","h1",null,{"className":"mt-2 text-2xl font-semibold","children":"Lost in orbit"}],["$","p",null,{"className":"mt-2 max-w-sm text-muted","children":"The page you're looking for doesn't exist or has moved."}],["$","$L4",null,{"href":"/dashboard","className":"btn btn-primary mt-6","children":"Back to dashboard"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L5",null,{}]]}]]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":["$L6",null,["$","$L7",null,{"children":["$L8",["$","$L9",null,{"promise":"$@a"}]]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$Lb",null,{"children":"$Lc"}],null],["$","$Ld",null,{"children":["$","div",null,{"hidden":true,"children":["$","$e",null,{"fallback":null,"children":"$Lf"}]}]}]]}],false]],"m":"$undefined","G":["$10",[]],"s":false,"S":true}
6:E{"digest":"NEXT_REDIRECT;replace;/dashboard;307;"}
c:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#070a14"}]]
8:null
11:I[80622,[],"IconMark"]
a:{"metadata":[["$","title","0",{"children":"Team Sprint — work, in motion"}],["$","meta","1",{"name":"description","content":"Team Sprint is a modern issue-tracking and sprint-planning platform for fast-moving teams."}],["$","link","2",{"rel":"icon","href":"/icon.png?2991ddadadbb6c00","type":"image/png","sizes":"560x558"}],["$","$L11","3",{}]],"error":null,"digest":"$undefined"}
f:"$a:metadata"
